#pragma once

#include "MISAlgorithm.hpp"

namespace mis {

class BakerPTAS : public MISAlgorithm {
public:
    explicit BakerPTAS(int k);

    std::string name() const override {
        return "Baker-PTAS-1994";
    }

    IndependentSet run(
        const ogdf::Graph &G,
        unsigned int seed
    ) override;

private:
    int m_k; // parâmetro do PTAS
};

} // namespace mis
