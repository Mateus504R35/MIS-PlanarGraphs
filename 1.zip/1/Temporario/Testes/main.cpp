#include <ogdf/basic/Graph.h>

#include <chrono>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>
#include <filesystem>

#include <ogdf/fileformats/GraphIO.h>

#include "PlanarRandomDataset.hpp"
#include "ChibaAlgorithm.hpp"

// Se seus headers estiverem em subpasta, ajuste para:
// #include "mis/PlanarRandomDataset.hpp"
// #include "mis/ChibaAlgorithm.hpp"

static std::uint32_t splitmix32(std::uint32_t x) {
    // mistura barata e determinística para seeds
    x += 0x9e3779b9u;
    x ^= x >> 16;
    x *= 0x85ebca6bu;
    x ^= x >> 13;
    x *= 0xc2b2ae35u;
    x ^= x >> 16;
    return x;
}

static std::uint32_t deriveSeed(std::uint32_t baseSeed, int idx, int tag = 0) {
    return splitmix32(baseSeed ^ (std::uint32_t)idx * 0xA511E9B3u ^ (std::uint32_t)tag * 0x63D83595u);
}

static std::string genTypeToStr(mis::gen::PlanarGenType t) {
    return mis::gen::toString(t);
}


static void saveFailGraphGraphML(const ogdf::Graph &G, const std::string &path) {
    std::filesystem::create_directories(std::filesystem::path(path).parent_path());

    if (!ogdf::GraphIO::write(G, path.c_str())) {
        // fallback: tenta GML
        std::string gmlPath = path;
        auto p = gmlPath.rfind(".graphml");
        if (p != std::string::npos) gmlPath.replace(p, 7, ".gml");
        ogdf::GraphIO::write(G, gmlPath.c_str());
    }
}

int main(int argc, char **argv) {
    // Uso:
    //   ./sanityCheck [instances] [nMin] [nMax] [baseSeed] [outCsv]
    //
    // Exemplos:
    //   ./sanityCheck
    //   ./sanityCheck 100 20 80 123456 sanity_chiba.csv

    int instances = 60;
    int nMin = 15;
    int nMax = 80;
    std::uint32_t baseSeed = 123456u;
    std::string outCsv = "sanity_chiba.csv";

    if (argc >= 2) instances = std::stoi(argv[1]);
    if (argc >= 3) nMin = std::stoi(argv[2]);
    if (argc >= 4) nMax = std::stoi(argv[3]);
    if (argc >= 5) baseSeed = (std::uint32_t)std::stoul(argv[4]);
    if (argc >= 6) outCsv = argv[5];

    if (instances < 1) instances = 1;
    if (nMin < 3) nMin = 3;
    if (nMax < nMin) nMax = nMin;

    std::ofstream out(outCsv);
    if (!out) {
        std::cerr << "Erro: nao consegui abrir CSV: " << outCsv << "\n";
        return 1;
    }

    // CSV
    out << "instance,type,seed,n_target,m_target,n_actual,m_actual,solSize,independent,maximal,timeMs,exception\n";

    mis::ChibaAlgorithm alg;

    // Vamos testar os 3 tipos do seu gerador (Connected/Biconnected/Triconnected)
    std::vector<mis::gen::PlanarGenType> types = {
        mis::gen::PlanarGenType::Connected,
        mis::gen::PlanarGenType::Biconnected,
        mis::gen::PlanarGenType::Triconnected
    };

    int instanceId = 0;

    for (auto t : types) {
        for (int i = 0; i < instances; i++) {
            const std::uint32_t seed = deriveSeed(baseSeed, i, (int)t + 1);

            // n varia deterministicamente em [nMin, nMax]
            const int n = nMin + (int)(deriveSeed(seed, 777, 0) % (std::uint32_t)(nMax - nMin + 1));

            // limites de arestas para planaridade + restrição do tipo
            const int mMin = mis::gen::minEdges(t, n);
            const int mMax = mis::gen::maxPlanarEdges(n);

            // escolhe m em [mMin, mMax] (se possível)
            int m = mMin;
            if (mMax > mMin) {
                m = mMin + (int)(deriveSeed(seed, 888, 1) % (std::uint32_t)(mMax - mMin + 1));
            }

            // métricas
            int nA = 0, mA = 0, solSize = 0;
            bool indep = false, maximal = false;
            double timeMs = 0.0;
            std::string exMsg;
            ogdf::Graph G;
            bool graphReady = false;

            try {
                mis::gen::generateSingle(t, G, n, m, seed);

                graphReady = true;

                nA = G.numberOfNodes();
                mA = G.numberOfEdges();

                auto t0 = std::chrono::high_resolution_clock::now();
                auto S = alg.run(G, seed);
                auto t1 = std::chrono::high_resolution_clock::now();

                timeMs = std::chrono::duration<double, std::milli>(t1 - t0).count();

                solSize = S.size();
                indep = S.isIndependent();
                maximal = S.isMaximal();

                if (!indep) {
                    exMsg = "NOT_INDEPENDENT";
                }

            } catch (const std::exception &e) {
                exMsg = e.what();
            } catch (...) {
                exMsg = "UNKNOWN_EXCEPTION";
            }


            // Se falhou (independent=0) ou ocorreu exceção, salva o grafo em GraphML
            if (graphReady && (!exMsg.empty() || !indep)) {
                const std::string file =
                    "failed_graphs/" + genTypeToStr(t) +
                    "_id" + std::to_string(instanceId) +
                    "_n" + std::to_string(nA) +
                    "_m" + std::to_string(mA) +
                    "_seed" + std::to_string(seed) +
                    ".graphml";

                saveFailGraphGraphML(G, file);
            }

            out << instanceId << ","
                << genTypeToStr(t) << ","
                << seed << ","
                << n << ","
                << m << ","
                << nA << ","
                << mA << ","
                << solSize << ","
                << (indep ? 1 : 0) << ","
                << (maximal ? 1 : 0) << ","
                << timeMs << ","
                << "\"" << exMsg << "\""
                << "\n";

            instanceId++;

            if ((instanceId % 20) == 0) {
                std::cout << "Rodadas: " << instanceId
                          << " | tipo=" << genTypeToStr(t)
                          << " | n=" << nA << " m=" << mA
                          << " | sol=" << solSize
                          << " | indep=" << (indep ? "ok" : "FAIL")
                          << (exMsg.empty() ? "" : " | ex=YES")
                          << "\n";
            }
        }
    }

    std::cout << "CSV gerado: " << outCsv << "\n";
    return 0;
}