#include "ChibaAlgorithm.hpp"

#include <ogdf/basic/Graph.h>
#include <ogdf/basic/CombinatorialEmbedding.h>
#include <ogdf/basic/extended_graph_alg.h> // planarEmbed(...)

#include <vector>
#include <unordered_set>
#include <algorithm>
#include <stdexcept>

namespace mis {

// ------------------ Utils básicos ------------------

static bool hasEdge(ogdf::Graph &G, ogdf::node u, ogdf::node v) {
    return G.searchEdge(u, v) != nullptr || G.searchEdge(v, u) != nullptr;
}

static ogdf::node pickMinDegreeNode(ogdf::Graph &G) {
    ogdf::node best = nullptr;
    int bestDeg = 1e9;
    for (auto v : G.nodes) {
        int d = v->degree();
        if (d < bestDeg) {
            bestDeg = d;
            best = v;
        }
    }
    return best;
}

// embedding planar (combinatorial)
static bool computeEmbedding(ogdf::Graph &G, ogdf::CombinatorialEmbedding &E) {
    // Embute a planar embedding diretamente no Graph (ordem das adjacências)
    if (!ogdf::planarEmbed(G)) { // retorna false se não for planar
        return false;
    }

    // Agora o grafo está embedded -> dá pra construir o CombinatorialEmbedding
    E.init(G);          // ou: E = ogdf::CombinatorialEmbedding(G);
    E.computeFaces();   // recomendado se você for usar faces (não é estritamente necessário só pra rotação)
    return true;
}


// vizinhos em ordem cíclica ao redor de v (rotação da embedding)
static std::vector<ogdf::node> cyclicNeighbors(ogdf::node v) {
    std::vector<ogdf::node> ord;
    ogdf::adjEntry a0 = v->firstAdj();
    if (!a0) return ord;

    ogdf::adjEntry a = a0;
    do {
        ord.push_back(a->twinNode());
        a = a->cyclicSucc(); // rotação em torno de v
    } while (a != a0);

    return ord;
}


// ------------------ Construção de G' mantendo mapeamento p/ grafo original ------------------
//
// origCur[x] = nó do grafo original representado por x no grafo corrente.
//
// buildReducedGraph:
// - removeSet: nós do grafo corrente removidos (não entram em G')
// - mergeEdges: pares (keep, from):
//      para cada vizinho x de 'from' em G, adicionar aresta (keep, x) em G' (se x também não foi removido)

struct ReducedGraph {
    ogdf::Graph G;
    ogdf::NodeArray<ogdf::node> orig; // nó em G' -> nó no grafo original
};

static ReducedGraph buildReducedGraph(
    ogdf::Graph &G,
    const ogdf::NodeArray<ogdf::node> &origCur,
    const std::unordered_set<ogdf::node> &removeSet,
    const std::vector<std::pair<ogdf::node, ogdf::node>> &mergeEdges
) {
    ReducedGraph out;
    out.orig.init(out.G);

    ogdf::NodeArray<ogdf::node> mapOldToNew(G, nullptr);

    // cria nós não removidos
    for (auto v : G.nodes) {
        if (removeSet.find(v) != removeSet.end()) continue;
        ogdf::node nv = out.G.newNode();
        mapOldToNew[v] = nv;
        out.orig[nv] = origCur[v];
    }

    // copia arestas entre nós presentes
    for (auto e : G.edges) {
        ogdf::node a = e->source();
        ogdf::node b = e->target();
        if (!mapOldToNew[a] || !mapOldToNew[b]) continue;

        ogdf::node na = mapOldToNew[a];
        ogdf::node nb = mapOldToNew[b];
        if (na != nb && !hasEdge(out.G, na, nb)) {
            out.G.newEdge(na, nb);
        }
    }

    // adiciona arestas de "junção"
    for (auto [keep, from] : mergeEdges) {
        ogdf::node keepN = mapOldToNew[keep];
        if (!keepN) continue; // keep removido => ignora

        for (auto adj : from->adjEntries) {
            ogdf::node x = adj->twinNode();
            ogdf::node xN = mapOldToNew[x];
            if (!xN) continue;         // vizinho removido
            if (xN == keepN) continue; // laço

            if (!hasEdge(out.G, keepN, xN)) {
                out.G.newEdge(keepN, xN);
            }
        }
    }

    return out;
}

// ------------------ Grau 4 fiel ao artigo ------------------

struct Deg4Labels {
    ogdf::node a, b, c, d; // ordem cíclica
    bool isH4Cycle;        // H4: ciclo (a-b-c-d-a) sem diagonais
};

// N é a lista de vizinhos em ordem cíclica (tamanho 4)
static Deg4Labels labelDeg4FromEmbedding(ogdf::Graph &G, const std::vector<ogdf::node> &N) {
    Deg4Labels L{N[0], N[1], N[2], N[3], false};
    auto &a = L.a; auto &b = L.b; auto &c = L.c; auto &d = L.d;

    bool cycleEdges =
        hasEdge(G, a, b) && hasEdge(G, b, c) && hasEdge(G, c, d) && hasEdge(G, d, a);

    bool diagAC = hasEdge(G, a, c);
    bool diagBD = hasEdge(G, b, d);

    // H4 (ciclo): tem as 4 arestas do ciclo e não tem diagonais
    if (cycleEdges && !diagAC && !diagBD) {
        L.isH4Cycle = true;
        return L;
    }

    // Caso não-H4: o artigo permite renomear os vizinhos de forma que exista uma aresta (a,c)
    // entre dois vizinhos de v (não necessariamente opostos na rotação).
    // Então escolhemos QUALQUER aresta interna (u,w) no subgrafo induzido por N(v) e renomeamos:
    //   a = u, c = w, e os outros dois viram b e d (ordem irrelevante neste ramo).
    ogdf::node u = nullptr, w = nullptr;
    for (int i = 0; i < 4 && !u; i++) {
        for (int j = i + 1; j < 4; j++) {
            if (hasEdge(G, N[i], N[j])) {
                u = N[i];
                w = N[j];
                break;
            }
        }
    }

    if (!u) {
        throw std::runtime_error("Chiba deg=4: caso nao-H4 mas sem nenhuma aresta entre vizinhos (fora das hipoteses do artigo).");
    }

    a = u;
    c = w;

    std::vector<ogdf::node> rest;
    rest.reserve(2);
    for (auto x : N) {
        if (x != a && x != c) rest.push_back(x);
    }
    b = rest[0];
    d = rest[1];

    L.isH4Cycle = false;
    return L;
}

// ------------------ Grau 5 fiel ao artigo ------------------

struct Deg5Labels { ogdf::node a, b, c, d, e; };

// N é a lista de vizinhos em ordem cíclica (tamanho 5).
// O artigo assume que existe uma aresta (a,c) onde c é o "vizinho a dois passos" na rotação.
static Deg5Labels labelDeg5FromEmbedding(ogdf::Graph &G, const std::vector<ogdf::node> &N) {
    for (int i = 0; i < 5; i++) {
        ogdf::node ai = N[i];
        ogdf::node ci = N[(i + 2) % 5];
        if (hasEdge(G, ai, ci)) {
            Deg5Labels L;
            L.a = N[i];
            L.b = N[(i + 1) % 5];
            L.c = N[(i + 2) % 5];
            L.d = N[(i + 3) % 5];
            L.e = N[(i + 4) % 5];
            return L;
        }
    }

    // Fiel ao artigo: se não existe (a,c) com salto 2, algo está fora do caso assumido.
    throw std::runtime_error("Chiba deg=5: não encontrei aresta (a,c) com salto 2 na ordem cíclica do embedding.");
}

// ------------------ Recursão principal ------------------

static IndependentSet approxMISPlanarRec(
    ogdf::Graph &G,
    const ogdf::NodeArray<ogdf::node> &origCur,
    const ogdf::Graph &Goriginal
) {
    IndependentSet empty(Goriginal);

    if (G.numberOfNodes() == 0) {
        return empty;
    }

    // embedding planar do grafo corrente (necessário para deg 4 e 5 "fiel ao artigo")
    ogdf::CombinatorialEmbedding E;
    if (!computeEmbedding(G, E)) {
        throw std::runtime_error("Chiba: grafo corrente não é planar (embedding falhou).");
    }

    ogdf::node v = pickMinDegreeNode(G);
    int dv = v->degree();

    // planar => grau mínimo <= 5
    if (dv > 5) {
        throw std::runtime_error("Chiba: grau mínimo > 5; grafo não parece planar ou houve problema.");
    }

    // vizinhos de v na ordem cíclica do embedding
    auto N = cyclicNeighbors(v);


    // sanity
    if ((int)N.size() != dv) {
        // em princípio deve bater
        // mas se a API de cyclicSucc estiver errada, isso acusa rápido.
        throw std::runtime_error("Chiba: lista de vizinhos cíclicos não bate com degree(v).");
    }

    // ---- Caso grau(v) <= 2
    if (dv <= 2) {
        std::unordered_set<ogdf::node> removeSet;
        removeSet.insert(v);
        for (auto u : N) removeSet.insert(u);

        ReducedGraph R = buildReducedGraph(G, origCur, removeSet, {});
        IndependentSet S = approxMISPlanarRec(R.G, R.orig, Goriginal);

        // devolve S ∪ {v}
        S.add(origCur[v]);
        return S;
    }

    // ---- Caso grau(v) = 3
    if (dv == 3) {
        ogdf::node a = N[0], b = N[1], c = N[2];

        bool triangle = hasEdge(G, a, b) && hasEdge(G, b, c) && hasEdge(G, c, a);

        if (triangle) {
            // caso do triângulo:
            // G' = G sem {v, b, c}
            // juntar vizinhos de b ou c em a
            std::unordered_set<ogdf::node> removeSet = {v, b, c};
            std::vector<std::pair<ogdf::node, ogdf::node>> merges = {
                {a, b},
                {a, c}
            };

            ReducedGraph R = buildReducedGraph(G, origCur, removeSet, merges);
            IndependentSet S = approxMISPlanarRec(R.G, R.orig, Goriginal);

            if (!S.contains(origCur[a])) {
                S.add(origCur[b]);
                S.add(origCur[c]);
            } else {
                S.add(origCur[v]);
            }
            return S;
        } else {
            // sem triângulo:
            // G' = G sem {v} ∪ N(v)
            std::unordered_set<ogdf::node> removeSet;
            removeSet.insert(v);
            for (auto u : N) removeSet.insert(u);

            ReducedGraph R = buildReducedGraph(G, origCur, removeSet, {});
            IndependentSet S = approxMISPlanarRec(R.G, R.orig, Goriginal);
            S.add(origCur[v]);
            return S;
        }
    }

    // ---- Caso grau(v) = 4 (fiel: usa rotação do embedding)
    if (dv == 4) {
        Deg4Labels L = labelDeg4FromEmbedding(G, N);
        ogdf::node a = L.a, b = L.b, c = L.c, d = L.d;

        if (L.isH4Cycle) {
            // H4: vizinhos em ciclo a-b-c-d-a
            // G' = G sem {v, b, d}
            // merge: vizinhos de b em a; vizinhos de d em c
            std::unordered_set<ogdf::node> removeSet = {v, b, d};
            std::vector<std::pair<ogdf::node, ogdf::node>> merges = {
                {a, b},
                {c, d}
            };

            ReducedGraph R = buildReducedGraph(G, origCur, removeSet, merges);
            IndependentSet S = approxMISPlanarRec(R.G, R.orig, Goriginal);

            if (!S.contains(origCur[a]) && !S.contains(origCur[c])) {
                S.add(origCur[v]);
            } else if (S.contains(origCur[a])) {
                // substitui a por b (a é adjacente a b no original)
                S.remove(origCur[a]);
                S.add(origCur[b]);
            } else { // c ∈ S
                // substitui c por d (c é adjacente a d no original)
                S.remove(origCur[c]);
                S.add(origCur[d]);
            }
            return S;
        } else {
            // H4' ou H4'': com diagonal (a,c) após renomeação
            // G' = G sem {v, b, c, d}
            // merge: vizinhos de c em a
            std::unordered_set<ogdf::node> removeSet = {v, b, c, d};
            std::vector<std::pair<ogdf::node, ogdf::node>> merges = {
                {a, c}
            };

            ReducedGraph R = buildReducedGraph(G, origCur, removeSet, merges);
            IndependentSet S = approxMISPlanarRec(R.G, R.orig, Goriginal);

            if (S.contains(origCur[a])) {
                // substitui a por c (a é adjacente a c no original)
                S.remove(origCur[a]);
                S.add(origCur[c]);
            } else {
                S.add(origCur[v]);
            }
            return S;
        }
    }

    // ---- Caso grau(v) = 5 (fiel: usa rotação e encontra (a,c) com salto 2)
    if (dv == 5) {
        Deg5Labels L = labelDeg5FromEmbedding(G, N);
        ogdf::node a = L.a, b = L.b, c = L.c, d = L.d, e = L.e;

        // G' = G sem {v, b, c, d, e} (mantém a)
        // merge: vizinhos de c em a
        std::unordered_set<ogdf::node> removeSet = {v, b, c, d, e};
        std::vector<std::pair<ogdf::node, ogdf::node>> merges = {
            {a, c}
        };

        ReducedGraph R = buildReducedGraph(G, origCur, removeSet, merges);
        IndependentSet S = approxMISPlanarRec(R.G, R.orig, Goriginal);

        if (S.contains(origCur[a])) {
            // substitui a por c (a é adjacente a c no original)
            S.remove(origCur[a]);
            S.add(origCur[c]);
        } else {
            S.add(origCur[v]);
        }
        return S;
    }

    // não deveria chegar aqui
    throw std::runtime_error("Chiba: caso não tratado.");
}

// ------------------ API pública ------------------

IndependentSet ChibaAlgorithm::run(const ogdf::Graph &G, unsigned int /*seed*/) {
    // Faz cópia mutável para poder planarEmbed e para as reduções recursivas
    ogdf::Graph Gwork(G);

    // Mapeamento inicial: nó em Gwork -> nó no G original
    ogdf::NodeArray<ogdf::node> origCur(Gwork);

    // Precisa mapear corretamente os nós da cópia para os nós do original:
    // jeito robusto: criar uma lista paralela pela ordem de criação dos nós.
    // OGDF garante iteração em nodes, mas não garante que a cópia preserve "ponteiros".
    // Então montamos vetores em ordem de iteração e pareamos.
    std::vector<ogdf::node> origNodes;
    origNodes.reserve(G.numberOfNodes());
    for (auto v : G.nodes) origNodes.push_back(v);

    std::vector<ogdf::node> workNodes;
    workNodes.reserve(Gwork.numberOfNodes());
    for (auto v : Gwork.nodes) workNodes.push_back(v);

    if (origNodes.size() != workNodes.size()) {
        throw std::runtime_error("Chiba: cópia do grafo gerou número diferente de nós.");
    }

    for (size_t i = 0; i < workNodes.size(); i++) {
        origCur[workNodes[i]] = origNodes[i];
    }

    return approxMISPlanarRec(Gwork, origCur, G);
}


} // namespace mis