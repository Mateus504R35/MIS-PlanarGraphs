#include "ChoukhmaneFrancoAlgorithm.hpp"
#include "PlanarMaxCutHadlock.hpp"

#include <ogdf/basic/Graph.h>
#include <stdexcept>

namespace mis {

IndependentSet ChoukhmaneFrancoAlgorithm::run(const ogdf::Graph &G, unsigned int /*seed*/) {
    // CF é determinístico dado o Hadlock (seed não usado aqui, mas mantemos a assinatura padrão).
    if (G.numberOfNodes() == 0) return IndependentSet(G);

    // 1) Hadlock: maximum cut => side[v] em {0,1} define X/Y
    ogdf::NodeArray<int> side = planarMaxCutHadlock(G);

    // 2) X e Y iniciais (conjuntos de vértices por lado)
    ogdf::NodeArray<bool> inX(G, false), inY(G, false);
    for (auto v : G.nodes) {
        if (side[v] == 0) inX[v] = true;
        else             inY[v] = true;
    }

    // 3) Para cada aresta que NÃO cruza o corte (u,v no mesmo lado),
    //    remove um endpoint do lado correspondente, conforme pseudocódigo.
    for (auto e : G.edges) {
        ogdf::node u = e->source();
        ogdf::node v = e->target();

        if (side[u] == side[v]) {
            if (side[u] == 0) {
                // u,v em X => remove u de X
                inX[u] = false;
            } else {
                // u,v em Y => remove u de Y
                inY[u] = false;
            }
        }
    }

    // 4) Escolhe o maior lado: X ou Y (cada um vira conjunto independente)
    int sizeX = 0, sizeY = 0;
    for (auto v : G.nodes) {
        if (inX[v]) ++sizeX;
        if (inY[v]) ++sizeY;
    }

    IndependentSet I(G);
    if (sizeX >= sizeY) {
        for (auto v : G.nodes) if (inX[v]) I.unsafeAdd(v);
    } else {
        for (auto v : G.nodes) if (inY[v]) I.unsafeAdd(v);
    }

    // Checagem defensiva (ótimo pra debug/log)
    if (!I.isIndependent()) {
        throw std::runtime_error("CF: conjunto retornado nao e independente (bug na biparticao/remocoes).");
    }
    return I;
}

} // namespace mis
