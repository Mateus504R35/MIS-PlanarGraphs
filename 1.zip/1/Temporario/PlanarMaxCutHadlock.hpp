#pragma once

#include <ogdf/basic/Graph.h>

namespace mis {

/**
 * Retorna uma bipartição (side[v] = 0/1) que maximiza o número de arestas cruzando o corte
 * (Maximum Cut) para grafos planares — alvo: implementação do algoritmo de Hadlock (1975).
 *
 * OBS: O subgrafo formado pelas arestas cruzando o corte é bipartido.
 */
ogdf::NodeArray<int> planarMaxCutHadlock(const ogdf::Graph &G);

} // namespace mis
