#pragma once

#include "MISAlgorithm.hpp"
#include "MISContext.hpp"

namespace mis {

class ChoukhmaneFrancoAlgorithm : public MISAlgorithm {
public:
    std::string name() const override {
        return "Choukhmane-Franco-1986";
    }

    IndependentSet run(
        const ogdf::Graph &G,
        unsigned int seed
    ) override;
};

} // namespace mis
