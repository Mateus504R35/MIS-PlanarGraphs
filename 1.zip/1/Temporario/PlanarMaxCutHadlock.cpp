#include "PlanarMaxCutHadlock.hpp"

#include <ogdf/basic/simple_graph_alg.h>   // isPlanar
#include <stdexcept>

namespace mis {

ogdf::NodeArray<int> planarMaxCutHadlock(const ogdf::Graph &G) {

    ogdf::NodeArray<int> side(G, 0);

    // ============================================================
    // TODO (Hadlock 1975):
    // Implementar o algoritmo polinomial de máximo corte em grafos planares.
    //
    // Estratégia correta: usar embedding planar + construção auxiliar (dual/gadgets)
    // e resolver a subrotina polinomial equivalente descrita por Hadlock.
    //
    // Por enquanto: placeholder determinístico (não é Hadlock!)
    // ============================================================
    int flip = 0;
    for (auto v : G.nodes) {
        side[v] = flip;
        flip ^= 1;
    }
    return side;
}

} // namespace mis
