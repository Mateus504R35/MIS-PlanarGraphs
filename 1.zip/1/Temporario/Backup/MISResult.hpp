#pragma once

#include <string>
#include <chrono>

namespace mis {

struct RunResult {
    std::string algorithm;
    int n;
    int m;

    int solutionSize;
    bool isIndependent;
    bool isMaximal;

    unsigned int seed;
    double timeMs;

    // parâmetros específicos (ex: k do Baker)
    int paramK = -1;
};

} // namespace mis
