#pragma once

#include <ogdf/basic/Graph.h>
#include <random>

namespace mis {

struct AlgorithmContext {
    const ogdf::Graph *G;

    // estado comum útil
    ogdf::NodeArray<bool> active;     // vértices ainda no subgrafo
    ogdf::NodeArray<int> degree;      // grau no subgrafo ativo

    // RNG (reprodutibilidade)
    std::mt19937 rng;
    unsigned int seed;

    explicit AlgorithmContext(const ogdf::Graph &graph, unsigned int s)
        : G(&graph),
          active(graph, true),
          degree(graph, 0),
          rng(s),
          seed(s)
    {
        for (auto v : graph.nodes)
            degree[v] = v->degree();
    }
};

} // namespace mis
