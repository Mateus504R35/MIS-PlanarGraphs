#pragma once

#include <ogdf/basic/Graph.h>

#include <cstdint>
#include <vector>

class BakerMIS {
public:
    // - Parâmetros do algoritmo de Baker
    struct Params { 
        int k = 4; // k >= 1 (quanto maior, melhor aproximação, mais caro)
        // segurança: se a decomposição ficar grande demais (bag grande), aborta/fallback
        int maxBagSizeAllowed = 28; // 2^28 ainda é pesado, mas evitamos explosões
    };

    // Retorna conjunto independente como IDs (compatível com seu pipeline do Chiba)
    // atalho: usa Params padrão
    static std::vector<int> run(const ogdf::Graph &G, const ogdf::NodeArray<int> &idsOrig);

    // versão configurável
    static std::vector<int> run(const ogdf::Graph &G,
                                const ogdf::NodeArray<int> &idsOrig,
                                const Params &p);


private:
    // ====== Etapa "Baker": embedding + níveis + remover classe ======

    // - Função que calula o conjunto de níveis do grafo
    static bool computePlanarLevels(const ogdf::Graph &G,
                                    const ogdf::NodeArray<int> &idsOrig,
                                    std::vector<int> &levelById);

    // - Função que cria adjacência por IDS (estrutura auxiliar )                              
    static void buildAdjacencyById(const ogdf::Graph &G,
                                   const ogdf::NodeArray<int> &idsOrig,
                                   std::vector<std::vector<int>> &adj);

    // - Função que retorna os componentes conexos do subgrafo induzido
    static void connectedComponentsInduced(const std::vector<std::vector<int>> &adj,
                                           const std::vector<char> &active,
                                           std::vector<std::vector<int>> &comps);

    // ====== Sub-rotina exata em k-outerplanar: MIS via Tree Decomposition ======
    // - Função que resolve o MIS exatamente no subgrafo k-Externoplanar
    static std::vector<int> solveMIS_kOuterplanar_exact_TW(const std::vector<std::vector<int>> &adj,
                                                          const std::vector<int> &component,
                                                          const Params &p);

    // (Eliminação -> bags -> árvore de decomposição)
    // - Definição de nós da árvore de decomposição
    struct TDNode {
        std::vector<int> bag;        // vertices (IDs)
        std::vector<int> children;   // índices na TD
        int parent = -1;
    };

    // - Função que cria a árvore de decomposição (usa heurística de eliminação min-degree + fill-in em vez de decomposição por slices do artigo)
    static bool buildTreeDecomposition_MinDegree(const std::vector<std::vector<int>> &adj,
                                                 const std::vector<int> &component,
                                                 std::vector<TDNode> &td,
                                                 int &root,
                                                 int &maxBagSize);

    // - Função que roda a programação dinâmica para o MIS usando a árvore de decomposição
    static bool runDPOnTD_MIS(const std::vector<std::vector<int>> &adj,
                             std::vector<TDNode> &td,
                             int root,
                             int maxBagSizeAllowed,
                             std::vector<int> &bestSet);

    // - Função que checa se o bag é independente
    static bool bagMaskIsIndependent(const std::vector<std::vector<int>> &adj,
                                     const std::vector<int> &bag,
                                     std::uint64_t mask,
                                     const std::vector<int> &posInBagOrMinus1);
};
