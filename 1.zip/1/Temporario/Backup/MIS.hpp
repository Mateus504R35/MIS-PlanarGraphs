#pragma once

#include <ogdf/basic/Graph.h>
#include <vector>

namespace mis{
    class IndependentSet {
    public:
        explicit IndependentSet(const ogdf::Graph &G);

        // operações seguras
        bool add(ogdf::node v);        // checa vizinhança
        bool remove(ogdf::node v);
        bool contains(ogdf::node v) const;

        // operações "unsafe" (uso controlado, ex: Baker)
        void unsafeAdd(ogdf::node v);

        // info
        int size() const;
        void clear();

        bool isIndependent() const;
        bool isMaximal() const;

        const std::vector<ogdf::node>& vertices() const;

    private:
        const ogdf::Graph *m_G;
        ogdf::NodeArray<bool> m_in;
        std::vector<ogdf::node> m_list;

        bool canAdd(ogdf::node v) const;
    };
}