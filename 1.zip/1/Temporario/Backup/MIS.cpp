#include "MIS.hpp"

#include <algorithm>

namespace mis {

IndependentSet::IndependentSet(const ogdf::Graph &G)
    : m_G(&G), m_in(G, false) {}

bool IndependentSet::canAdd(ogdf::node v) const {
    if (m_in[v]) return false;

    for (auto adj : v->adjEntries) {
        ogdf::node u = adj->twinNode();
        if (m_in[u]) return false;
    }
    return true;
}

bool IndependentSet::add(ogdf::node v) {
    if (!canAdd(v)) return false;
    m_in[v] = true;
    m_list.push_back(v);
    return true;
}

void IndependentSet::unsafeAdd(ogdf::node v) {
    // Use apenas quando o algoritmo já garante independência (ex: materialização do Baker)
    if (!m_in[v]) {
        m_in[v] = true;
        m_list.push_back(v);
    }
}

bool IndependentSet::remove(ogdf::node v) {
    if (!m_in[v]) return false;

    m_in[v] = false;

    auto it = std::find(m_list.begin(), m_list.end(), v);
    if (it != m_list.end()) {
        *it = m_list.back();
        m_list.pop_back();
    }
    return true;
}

bool IndependentSet::contains(ogdf::node v) const {
    return m_in[v];
}

int IndependentSet::size() const {
    return static_cast<int>(m_list.size());
}

void IndependentSet::clear() {
    for (auto v : m_list) m_in[v] = false;
    m_list.clear();
}

bool IndependentSet::isIndependent() const {
    // Verifica todas as arestas: se endpoints estão no conjunto, falhou.
    for (auto e : m_G->edges) {
        ogdf::node a = e->source();
        ogdf::node b = e->target();
        if (m_in[a] && m_in[b]) return false;
    }
    return true;
}

bool IndependentSet::isMaximal() const {
    // Maximal: para todo v fora do conjunto, existe vizinho u dentro do conjunto
    for (auto v : m_G->nodes) {
        if (m_in[v]) continue;

        bool dominated = false;
        for (auto adj : v->adjEntries) {
            ogdf::node u = adj->twinNode();
            if (m_in[u]) { dominated = true; break; }
        }
        if (!dominated) return false;
    }
    return true;
}

const std::vector<ogdf::node>& IndependentSet::vertices() const {
    return m_list;
}

} // namespace mis
