#include "baker_mis.hpp"

#include <ogdf/basic/basic.h>

// - Bibliotecas usadas para representação planar e face externa 
#include <ogdf/planarity/BoyerMyrvold.h> 
#include <ogdf/basic/CombinatorialEmbedding.h>

#include <algorithm>
#include <chrono>
#include <cstdint>
#include <deque>
#include <iostream>
#include <limits>
#include <unordered_map>
#include <unordered_set>

// ============================
// Helpers gerais
// ============================

// - Função que conta bits de uma máscara (usado na programação dinâmica em bags)
static inline int popcount64(std::uint64_t x) {
#if defined(__GNUG__) || defined(__clang__)
    return __builtin_popcountll(x);
#else
    // fallback simples
    int c = 0;
    while (x) { x &= (x - 1); ++c; }
    return c;
#endif
}

// Cria um mapa id -> índice 0..(n-1) (assumimos idsOrig já é 0..n-1 como na sua main)
// - Função que recupera o valor de 'n'
static inline int inferNFromIds(const ogdf::Graph &G, const ogdf::NodeArray<int> &idsOrig) {
    int mx = -1;
    for (ogdf::node v : G.nodes) mx = std::max(mx, idsOrig[v]);
    return mx + 1;
}

// ============================
// BakerMIS::run
// ============================

// - Função que chama o algoritmo de Baker (versão atalho)
std::vector<int> BakerMIS::run(const ogdf::Graph &G,
                               const ogdf::NodeArray<int> &idsOrig) {
    return run(G, idsOrig, Params{}); // chama a versão com parâmetros
}

// - Função que chama o algoritmo de Baker (versão configurável)
//   --> Recebe como parâmetros: um grafo 'G', um conjunto de vértices 'idsOrig' e o conjunto de parâmetros 'p'
std::vector<int> BakerMIS::run(const ogdf::Graph &G,
                               const ogdf::NodeArray<int> &idsOrig,
                               const Params &p) {
    
    // - Determina o valor de 'n' do grafo 'G'
    const int n = inferNFromIds(G, idsOrig);
    

    // - Cria a lista de adjacência de 'G' por 'ID'
    std::vector<std::vector<int>> adj;
    buildAdjacencyById(G, idsOrig, adj);

    // - Declara o conjunto de níveis do grafo
    std::vector<int> levelById(n, -1);

    // - Calcula os níveis do grafo a partir da representação planar
    if (!computePlanarLevels(G, idsOrig, levelById)) {
        std::cerr << "[BakerMIS] ERRO: falha ao computar embedding/niveis.\n";
        return {};
    }

    // - Declara o conjunto solução 'bestI' 
    std::vector<int> bestI;
    bestI.reserve(n);

    // - Escopo do loop principal (Algoritmo 1: BAKER_MIS)
    for (int r = 0; r <= p.k; ++r) {
        // - Declara o conjunto 'active' usado para remover classe
        std::vector<char> active(n, 0);

        // - Loop para percorrer o conjunto de níveis
        for (int id = 0; id < n; ++id) {
            
            if (levelById[id] < 0) continue; // nó inexistente (não deve ocorrer se ids são 0..n-1)

            // - Calcula r (mod k+1)
            const int mod = levelById[id] % (p.k + 1);

            // - Marca nível como 'removido'
            if (mod != r) active[id] = 1;
        }

        // - Declara conjunto de componentes conexos
        std::vector<std::vector<int>> comps;

        // - Obtém componentes conexos do grafo
        connectedComponentsInduced(adj, active, comps);

        // - Declara conjunto solução da classe
        std::vector<int> Ir;

        // - Loop para percorrer o conjunto de componentes conexos
        for (const auto &C : comps) {
            if (C.empty()) continue;

            // - Declara o conjunto solução do componente e chama a função para resolver exatamente o MIS
            auto Ic = solveMIS_kOuterplanar_exact_TW(adj, C, p);

            // - Insere a solução do componente no conjunto de solução da classe
            Ir.insert(Ir.end(), Ic.begin(), Ic.end());
        }

        // - Escolhe o melhor conjunto entre as k+1 iterações
        if (Ir.size() > bestI.size()) bestI = std::move(Ir);
    }

    // - Remove duplicações e organiza os vértices do conjunto solução 
    std::sort(bestI.begin(), bestI.end());
    bestI.erase(std::unique(bestI.begin(), bestI.end()), bestI.end());
    return bestI;
}

// ============================
// Adjacência por ID
// ============================

// - Função que cria adjacência por IDs
//   --> Parâmetros: grafo 'G', lista de vértices 'idsOrig' e vetor 'adj' para armazenar a lista
void BakerMIS::buildAdjacencyById(const ogdf::Graph &G,
                                  const ogdf::NodeArray<int> &idsOrig,
                                  std::vector<std::vector<int>> &adj) {
    // - Obtém o 'n' do grafo
    const int n = inferNFromIds(G, idsOrig);
    adj.assign(n, {});

    // - Monta 'adj' a partir das arestas de um grafo 'OGDF'
    for (ogdf::edge e : G.edges) {
        int a = idsOrig[e->source()];
        int b = idsOrig[e->target()];
        if (a == b) continue;
        adj[a].push_back(b);
        adj[b].push_back(a);
    }

    // - Ordena lista
    for (int i = 0; i < n; ++i) {
        auto &v = adj[i];
        std::sort(v.begin(), v.end());
        v.erase(std::unique(v.begin(), v.end()), v.end());
    }
}

// ============================
// Componentes conexos no subgrafo induzido por active
// ============================

// -- Função que obtém os componentes conexos do grafo
//    --> Parâmetros: vetor 'adj' de adjacência, vetor 'active' para saber se uma classe foi removida do grafo, vetor 'comps' de componentes
void BakerMIS::connectedComponentsInduced(const std::vector<std::vector<int>> &adj,
                                          const std::vector<char> &active,
                                          std::vector<std::vector<int>> &comps) {
                                            
    // - Usa BFS e DFS no subgrafo induzido
    const int n = (int)adj.size();
    std::vector<char> vis(n, 0);

    for (int s = 0; s < n; ++s) {
        if (!active[s] || vis[s]) continue;
        std::vector<int> comp;
        std::deque<int> dq;
        dq.push_back(s);
        vis[s] = 1;

        while (!dq.empty()) {
            int u = dq.front();
            dq.pop_front();
            comp.push_back(u);

            for (int v : adj[u]) {
                if (!active[v] || vis[v]) continue;
                vis[v] = 1;
                dq.push_back(v);
            }
        }

        comps.push_back(std::move(comp));
    }
}

// ============================
// Níveis (Algoritmo 2 do seu PDF)
// Implementação prática:
// - Copiamos o grafo para H
// - Enquanto H não vazio: computa embedding planar, pega vértices da face externa,
//   marca nível e remove do H.
// Observação: isso pode ser mais caro que o "linear assumido" no artigo,
// mas mantém a definição de níveis do pseudocódigo.
// ============================

static void outerFaceVertices(ogdf::CombinatorialEmbedding &E,
                             std::vector<ogdf::node> &outNodes) {
    outNodes.clear();

    ogdf::face ext = E.externalFace();
    if (!ext) return;

    ogdf::adjEntry start = ext->firstAdj();
    ogdf::adjEntry a = start;

    // evita duplicados
    std::unordered_set<ogdf::node> seen;
    int guard = 0;
    const int guardMax = 1000000;

    do {
        ogdf::node v = a->theNode();
        if (seen.insert(v).second) outNodes.push_back(v);

        // caminha na borda da face (API típica OGDF)
        a = a->faceCycleSucc();

        if (++guard > guardMax) break;
    } while (a != start);
}


bool BakerMIS::computePlanarLevels(const ogdf::Graph &G,
                                  const ogdf::NodeArray<int> &idsOrig,
                                  std::vector<int> &levelById) {
    // Copia estrutural simples: recria H e mantém mapeamento node(H) -> id original
    ogdf::Graph H;
    ogdf::NodeArray<int> idH(H, -1);

    // cria nós
    std::unordered_map<int, ogdf::node> byId;
    byId.reserve(G.numberOfNodes() * 2);

    for (ogdf::node v : G.nodes) {
        ogdf::node u = H.newNode();
        int id = idsOrig[v];
        idH[u] = id;
        byId[id] = u;
    }

    // cria arestas
    for (ogdf::edge e : G.edges) {
        int a = idsOrig[e->source()];
        int b = idsOrig[e->target()];
        if (a == b) continue;
        auto ita = byId.find(a);
        auto itb = byId.find(b);
        if (ita == byId.end() || itb == byId.end()) continue;
        H.newEdge(ita->second, itb->second);
    }

    // Planaridade + peeling
    ogdf::BoyerMyrvold bm;
    int level = 1;

    while (H.numberOfNodes() > 0) {
        if (!bm.isPlanar(H)) return false;

        bm.planarEmbed(H);
        ogdf::CombinatorialEmbedding E(H);

        std::vector<ogdf::node> outer;
        outerFaceVertices(E, outer);

        if (outer.empty()) {
            for (ogdf::node v : H.nodes) outer.push_back(v);
        }

        for (ogdf::node v : outer) {
            int id = idH[v];
            if (id >= 0 && id < (int)levelById.size() && levelById[id] < 0) {
                levelById[id] = level;
            }
        }

        // remover nós externos
        for (ogdf::node v : outer) {
            H.delNode(v);
        }

        ++level;
    }

    return true;
}

// ============================
// ResolveMIS_kExternoPlanar(C): exato via Tree Decomposition
// ============================

std::vector<int> BakerMIS::solveMIS_kOuterplanar_exact_TW(const std::vector<std::vector<int>> &adj,
                                                         const std::vector<int> &component,
                                                         const Params &p) {
    // 1) constrói TD
    std::vector<TDNode> td;
    int root = -1;
    int maxBagSize = 0;

    if (!buildTreeDecomposition_MinDegree(adj, component, td, root, maxBagSize)) {
        // fallback muito simples: pega MIS guloso (não é exato, mas evita crash)
        std::vector<char> inComp(adj.size(), 0);
        for (int v : component) inComp[v] = 1;

        std::vector<int> order = component;
        std::sort(order.begin(), order.end(),
                  [&](int a, int b){ return adj[a].size() < adj[b].size(); });

        std::vector<char> used(adj.size(), 0);
        std::vector<int> S;
        for (int v : order) {
            if (used[v]) continue;
            bool ok = true;
            for (int u : adj[v]) if (inComp[u] && used[u]) { ok = false; break; }
            if (ok) {
                S.push_back(v);
                used[v] = 1;
                for (int u : adj[v]) if (inComp[u]) used[u] = 1;
            }
        }
        return S;
    }

    // 2) DP em TD (exato)
    std::vector<int> bestSet;
    if (!runDPOnTD_MIS(adj, td, root, p.maxBagSizeAllowed, bestSet)) {
        // se estourou por bag grande, faz o fallback guloso acima
        std::vector<char> inComp(adj.size(), 0);
        for (int v : component) inComp[v] = 1;

        std::vector<int> order = component;
        std::sort(order.begin(), order.end(),
                  [&](int a, int b){ return adj[a].size() < adj[b].size(); });

        std::vector<char> blocked(adj.size(), 0);
        std::vector<int> S;
        for (int v : order) {
            if (blocked[v]) continue;
            bool ok = true;
            for (int u : adj[v]) if (inComp[u] && !blocked[u] && false) {}
            // bloqueio já impede conflito, então basta inserir e bloquear vizinhos
            S.push_back(v);
            blocked[v] = 1;
            for (int u : adj[v]) if (inComp[u]) blocked[u] = 1;
        }
        return S;
    }

    return bestSet;
}

// ============================
// Tree decomposition por eliminação min-degree
// (não é mínima, mas em k-outerplanar costuma ficar pequena)
// ============================

bool BakerMIS::buildTreeDecomposition_MinDegree(const std::vector<std::vector<int>> &adj,
                                                const std::vector<int> &component,
                                                std::vector<TDNode> &td,
                                                int &root,
                                                int &maxBagSize) {
    // Conjunto do componente
    std::unordered_set<int> compSet(component.begin(), component.end());

    // Vizinhança mutável durante eliminação (subgrafo do componente)
    std::unordered_map<int, std::unordered_set<int>> N;
    N.reserve(component.size() * 2);

    for (int v : component) {
        auto &Nv = N[v];
        for (int u : adj[v]) {
            if (compSet.count(u)) Nv.insert(u);
        }
    }

    // ordem de eliminação via min-degree (simples)
    std::vector<int> order;
    order.reserve(component.size());

    std::unordered_set<int> alive(component.begin(), component.end());

    // Para conectar bags: precisamos do "índice de eliminação" depois
    std::unordered_map<int,int> elimIndex;

    // Bags temporários por vértice eliminado
    std::unordered_map<int, std::vector<int>> bagOfV;

    maxBagSize = 0;

    for (int step = 0; step < (int)component.size(); ++step) {
        // escolhe v com menor grau atual
        int bestV = -1;
        int bestDeg = std::numeric_limits<int>::max();

        for (int v : alive) {
            int deg = (int)N[v].size();
            if (deg < bestDeg) {
                bestDeg = deg;
                bestV = v;
            }
        }
        if (bestV < 0) break;

        // cria bag B = {v} U N(v)
        std::vector<int> bag;
        bag.reserve(N[bestV].size() + 1);
        bag.push_back(bestV);
        for (int u : N[bestV]) bag.push_back(u);

        std::sort(bag.begin(), bag.end());
        bag.erase(std::unique(bag.begin(), bag.end()), bag.end());

        bagOfV[bestV] = bag;
        elimIndex[bestV] = step;
        order.push_back(bestV);

        maxBagSize = std::max(maxBagSize, (int)bag.size());

        // fill-in: conecta vizinhos (clique)
        std::vector<int> neigh(N[bestV].begin(), N[bestV].end());
        for (size_t i = 0; i < neigh.size(); ++i) {
            for (size_t j = i + 1; j < neigh.size(); ++j) {
                int a = neigh[i], b = neigh[j];
                if (a == b) continue;
                N[a].insert(b);
                N[b].insert(a);
            }
        }

        // remove bestV
        for (int u : N[bestV]) N[u].erase(bestV);
        N.erase(bestV);
        alive.erase(bestV);
    }

    if ((int)order.size() != (int)component.size()) return false;

    // Constrói TD: um nó por bag de cada vértice (na ordem de eliminação)
    const int m = (int)order.size();
    td.assign(m, TDNode{});

    // map vertex -> td index (elimination step)
    std::unordered_map<int,int> tdIndexOfV;
    tdIndexOfV.reserve(m*2);
    for (int i = 0; i < m; ++i) {
        int v = order[i];
        td[i].bag = bagOfV[v];
        tdIndexOfV[v] = i;
    }

    // Conecta bags em árvore: para cada v, parent = bag do vizinho eliminado "mais tarde" (menor elimIndex maior que v)
    // (Heurística padrão para TD a partir de eliminação)
    for (int i = 0; i < m; ++i) {
        int v = order[i];
        const auto &bag = td[i].bag;

        int parentIdx = -1;
        int parentElim = std::numeric_limits<int>::max();

        // entre os vizinhos de v no bag (exceto v), pegue o que foi eliminado depois (elimIndex maior)
        for (int u : bag) {
            if (u == v) continue;
            auto it = elimIndex.find(u);
            if (it == elimIndex.end()) continue;
            int eu = it->second;
            if (eu > elimIndex[v] && eu < parentElim) {
                parentElim = eu;
                parentIdx = tdIndexOfV[u];
            }
        }

        td[i].parent = parentIdx;
        if (parentIdx >= 0) td[parentIdx].children.push_back(i);
    }

    // root é algum nó sem pai (normalmente o último eliminado)
    root = -1;
    for (int i = 0; i < m; ++i) {
        if (td[i].parent < 0) { root = i; break; }
    }
    if (root < 0) root = m - 1;

    return true;
}

// ============================
// Checagem de independência dentro do bag (usando adj global)
// posInBagOrMinus1: map v->pos dentro do bag, ou -1
// ============================

bool BakerMIS::bagMaskIsIndependent(const std::vector<std::vector<int>> &adj,
                                    const std::vector<int> &bag,
                                    std::uint64_t mask,
                                    const std::vector<int> &posInBagOrMinus1) {
    // para cada v selecionado, checa se há vizinho u selecionado no bag
    for (size_t i = 0; i < bag.size(); ++i) {
        if (((mask >> i) & 1ull) == 0ull) continue;
        int v = bag[i];
        for (int u : adj[v]) {
            int pu = (u >= 0 && u < (int)posInBagOrMinus1.size()) ? posInBagOrMinus1[u] : -1;
            if (pu < 0) continue;
            if (pu == (int)i) continue;
            if (((mask >> pu) & 1ull) != 0ull) return false;
        }
    }
    return true;
}

// ============================
// DP no TD (rooted) para MIS
// Definição do dp (sem “nice TD”):
// - dp_u[mask] = melhor MIS no subárvore de u, condicionado ao conjunto escolhido na bag(u) = mask
// - contagem: só conta vértices “introduzidos” em u (bag(u) \ bag(parent))
// - compatibilidade com filho: máscaras devem coincidir na interseção bag(u) ∩ bag(filho)
// ============================

bool BakerMIS::runDPOnTD_MIS(const std::vector<std::vector<int>> &adj,
                             std::vector<TDNode> &td,
                             int root,
                             int maxBagSizeAllowed,
                             std::vector<int> &bestSet) {
    // pós-ordem
    std::vector<int> post;
    post.reserve(td.size());
    {
        std::vector<int> st = {root};
        std::vector<char> vis(td.size(), 0);
        while (!st.empty()) {
            int u = st.back();
            if (!vis[u]) {
                vis[u] = 1;
                for (int c : td[u].children) st.push_back(c);
            } else {
                st.pop_back();
                post.push_back(u);
            }
        }
    }

    // dp tables e backtracking
    // Para cada u:
    // - dp[u][mask] = best value
    // - choose[u][childIndex][maskParent] = bestMaskChild (para reconstrução)
    struct ChildChoice {
        // para cada mask do pai, qual mask do filho escolhemos
        std::vector<std::uint32_t> bestMaskForParent;
    };

    std::vector<std::vector<int>> dp(td.size());
    std::vector<std::vector<ChildChoice>> choice(td.size());

    // Também guardamos para reconstrução final: qual mask no root dá o melhor valor
    int bestRootMask = 0;
    int bestRootVal  = -1;

    // Processa bottom-up
    for (int u : post) {
        const auto &bagU = td[u].bag;
        const int bU = (int)bagU.size();
        if (bU > 63) return false; // máscara 64-bit
        if (bU > maxBagSizeAllowed) return false;

        // map global vertex id -> pos no bag (vetor grande seria caro; aqui fazemos map compacto com unordered_map)
        // para acelerar a checagem de independência, criamos um posInBag "parcial" via unordered_map e um vector fallback
        int maxIdSeen = 0;
        for (int v : bagU) maxIdSeen = std::max(maxIdSeen, v);
        std::vector<int> posInBag(maxIdSeen + 1, -1);
        for (int i = 0; i < bU; ++i) {
            int v = bagU[i];
            if (v >= 0 && v < (int)posInBag.size()) posInBag[v] = i;
        }

        // intro vertices = bagU \ bagParent
        std::vector<char> inParent(bU, 0);
        if (td[u].parent >= 0) {
            const auto &bagP = td[td[u].parent].bag;
            std::unordered_set<int> setP(bagP.begin(), bagP.end());
            for (int i = 0; i < bU; ++i) if (setP.count(bagU[i])) inParent[i] = 1;
        }

        // Pré-computa lista de filhos e interseções
        const int deg = (int)td[u].children.size();
        choice[u].assign(deg, ChildChoice{});

        // dp size = 2^bU
        const int SZ = (1 << bU);
        dp[u].assign(SZ, -1);

        // Para cada filho, vamos precisar mapear interseção e enumerar máscaras compatíveis.
        // Preparação por filho:
        struct ChildInfo {
            int c;
            std::vector<int> posU_for_common; // posições no U
            std::vector<int> posC_for_common; // posições no C
            // tabela: para cada maskU, qual “assinatura” na interseção (bits compactados)
            // e para cada maskC, mesma assinatura
        };

        std::vector<ChildInfo> childInfos;
        childInfos.reserve(deg);

        for (int idx = 0; idx < deg; ++idx) {
            int c = td[u].children[idx];
            const auto &bagC = td[c].bag;

            if ((int)bagC.size() > maxBagSizeAllowed) return false;

            std::unordered_map<int,int> posC;
            posC.reserve(bagC.size() * 2);
            for (int i = 0; i < (int)bagC.size(); ++i) posC[bagC[i]] = i;

            ChildInfo info;
            info.c = c;

            for (int i = 0; i < bU; ++i) {
                auto it = posC.find(bagU[i]);
                if (it != posC.end()) {
                    info.posU_for_common.push_back(i);
                    info.posC_for_common.push_back(it->second);
                }
            }
            childInfos.push_back(std::move(info));
        }

        // Para cada filho, cria um “bestForSignature”:
        // signature = bits selecionados na interseção (tamanho <= bag)
        // bestVal[signature] = max dp_child[maskC] dentre masks com essa assinatura
        // bestMask[signature] = qual maskC atingiu
        std::vector<std::vector<int>> bestValPerChild(deg);
        std::vector<std::vector<std::uint32_t>> bestMaskPerChild(deg);

        for (int idx = 0; idx < deg; ++idx) {
            int c = td[u].children[idx];
            const auto &bagC = td[c].bag;
            const int bC = (int)bagC.size();
            const int SZC = (1 << bC);

            const auto &info = childInfos[idx];
            const int common = (int)info.posU_for_common.size();
            const int SIGSZ = (1 << common);

            bestValPerChild[idx].assign(SIGSZ, -1);
            bestMaskPerChild[idx].assign(SIGSZ, 0);

            // varre todas máscaras do filho
            for (int m = 0; m < SZC; ++m) {
                int val = dp[c][m];
                if (val < 0) continue;

                // signature do filho = bits na interseção (compactado)
                int sig = 0;
                for (int t = 0; t < common; ++t) {
                    int pc = info.posC_for_common[t];
                    if ((m >> pc) & 1) sig |= (1 << t);
                }

                if (val > bestValPerChild[idx][sig]) {
                    bestValPerChild[idx][sig] = val;
                    bestMaskPerChild[idx][sig] = (std::uint32_t)m;
                }
            }

            // choices: por mask do pai, escolhemos o melhor mask do filho com mesma assinatura
            choice[u][idx].bestMaskForParent.assign(SZ, 0);
        }

        // Agora computa dp[u][maskU]
        for (int mU = 0; mU < SZ; ++mU) {
            // 1) máscara deve ser independente dentro do bag
            if (!bagMaskIsIndependent(adj, bagU, (std::uint64_t)mU, posInBag)) continue;

            // 2) valor base = #introduzidos selecionados
            int base = 0;
            for (int i = 0; i < bU; ++i) {
                if (((mU >> i) & 1) && !inParent[i]) base++;
            }

            int sum = base;

            // 3) combina cada filho pelo melhor valor compatível na interseção
            bool ok = true;
            for (int idx = 0; idx < deg; ++idx) {
                const auto &info = childInfos[idx];
                const int common = (int)info.posU_for_common.size();

                int sigU = 0;
                for (int t = 0; t < common; ++t) {
                    int pu = info.posU_for_common[t];
                    if ((mU >> pu) & 1) sigU |= (1 << t);
                }

                int bestVal = bestValPerChild[idx][sigU];
                if (bestVal < 0) { ok = false; break; }

                sum += bestVal;

                // salva escolha pra reconstrução
                choice[u][idx].bestMaskForParent[mU] = bestMaskPerChild[idx][sigU];
            }

            if (!ok) continue;
            dp[u][mU] = sum;
        }

        // Se for raiz, escolhe melhor
        if (u == root) {
            for (int mU = 0; mU < (int)dp[u].size(); ++mU) {
                if (dp[u][mU] > bestRootVal) {
                    bestRootVal = dp[u][mU];
                    bestRootMask = mU;
                }
            }
        }
    }

    if (bestRootVal < 0) return false;

    // ========================
    // Reconstrução do conjunto
    // ========================
    bestSet.clear();
    bestSet.reserve(bestRootVal);

    std::unordered_set<int> selected;

    // DFS a partir da raiz, propagando máscaras escolhidas
    std::vector<std::pair<int,int>> st;
    st.push_back({root, bestRootMask});

    while (!st.empty()) {
        auto [u, mU] = st.back();
        st.pop_back();

        const auto &bagU = td[u].bag;
        // adiciona vertices "introduzidos" deste nó (evita duplicar via set)
        if (td[u].parent >= 0) {
            std::unordered_set<int> setP(td[td[u].parent].bag.begin(), td[td[u].parent].bag.end());
            for (int i = 0; i < (int)bagU.size(); ++i) {
                int v = bagU[i];
                if (setP.count(v)) continue;
                if ((mU >> i) & 1) selected.insert(v);
            }
        } else {
            // raiz: tudo é "introduzido"
            for (int i = 0; i < (int)bagU.size(); ++i) {
                if ((mU >> i) & 1) selected.insert(bagU[i]);
            }
        }

        // desce para filhos com as máscaras escolhidas
        for (int idx = 0; idx < (int)td[u].children.size(); ++idx) {
            int c = td[u].children[idx];
            int mC = (int)choice[u][idx].bestMaskForParent[mU];
            st.push_back({c, mC});
        }
    }

    bestSet.assign(selected.begin(), selected.end());
    std::sort(bestSet.begin(), bestSet.end());
    return true;
}
