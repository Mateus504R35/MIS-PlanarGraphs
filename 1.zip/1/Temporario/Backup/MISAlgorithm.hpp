/*
    - Interface comum para os algoritmos aproximados implementados no sistema;
*/

#pragma once

#include "MIS.hpp"
#include "MISContext.hpp"
#include <string>

namespace mis {

class MISAlgorithm {
public:
    virtual ~MISAlgorithm() = default;

    virtual std::string name() const = 0;

    virtual IndependentSet run(
        const ogdf::Graph &G,
        unsigned int seed
    ) = 0;
};

} // namespace mis
