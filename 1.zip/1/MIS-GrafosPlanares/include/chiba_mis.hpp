#pragma once

#include <ogdf/basic/Graph.h>
#include <ogdf/basic/GraphAttributes.h>
#include <vector>
#include <unordered_set>

class ChibaMIS {
public:
    // Retorna o conjunto independente como IDs de vértices (inteiros)
    // idsOrig: NodeArray<int> com o ID original de cada node do grafo de entrada.
    static std::vector<int> run(const ogdf::Graph &G, const ogdf::NodeArray<int> &idsOrig);

private:
    struct Instance {
        ogdf::Graph g;
        ogdf::NodeArray<int> origId; // map: node -> id original
        explicit Instance() : g(), origId(g, -1) {}
    };

    static std::vector<int> indpt(const Instance &I);

    // utilitários
    static ogdf::node pickMinDegreeVertex(const ogdf::Graph &g);
    static std::vector<ogdf::node> neighbors(const ogdf::Graph &g, ogdf::node v);
    static bool hasEdge(const ogdf::Graph &g, ogdf::node a, ogdf::node b);

    // constrói G' = G - removed, e depois adiciona arestas "join center -> adj(deleted)"
    // joins: lista de pares (centerOrigId, deletedOrigId) para "center joins neighbors of deleted"
    static Instance buildReduced(
        const Instance &I,
        const std::unordered_set<int> &removedOrigIds,
        const std::vector<std::pair<int,int>> &joins
    );

    // Caso DEGREE3/4/5 precisam rotular vizinhos em ordem cíclica no embedding.
    // Aqui usamos a ordem dada pelo planar embedding via GraphAttributes (adjEntry order).
    // Se o grafo não vier com embedding, a função tenta planarizar/embutir.
    static std::vector<ogdf::node> cyclicNeighborsPlanar(
        const Instance &I,
        ogdf::node v
    );

    // teste "H isomorphic with H4" (interpretado como: vizinhos em ciclo v1-v2-v3-v4-v1 e sem diagonais)
    static bool isH4Case(
        const Instance &I,
        ogdf::node v,
        const std::vector<ogdf::node> &cyc4
    );
};
