
#pragma once

#include <ogdf/basic/Graph.h>
#include <cstdint>
#include <filesystem>
#include <string>
#include <vector>

namespace mis::gen {

enum class PlanarGenType { Connected, Biconnected, Triconnected };
std::string toString(PlanarGenType t);

// - Definição do parâmetro de seed
enum class SeedMode { ParamHash, Sequential };

// - Definição de parâmetros de configuração da geração do dataset planar
struct GenerationConfig {
    std::filesystem::path outDir = "out_planar";
    std::string extension = ".gml";      // ".gml", ".graphml", ".dot", etc.
    int reps = 3;                        // grafos por combinação (tipo,n,c)
    std::uint32_t baseSeed = 12345;
    SeedMode seedMode = SeedMode::ParamHash;

    std::vector<int> sizes = {200, 500, 1000, 2000, 5000, 10000};
    std::vector<double> cs = {1.1, 1.5, 2.0, 2.5};
    std::vector<PlanarGenType> types = {
        PlanarGenType::Connected,
        PlanarGenType::Biconnected,
        PlanarGenType::Triconnected
    };
};

// - Definição dos status de geração 
struct GenerationStats {
    long long generated = 0; // - quando respeita a regra de planaridade
    long long skipped = 0; // - quando não respeita a regra de planaridade
    long long writeFail = 0; // - quando falha no registro do arquivo
};

int maxPlanarEdges(int n);
int minEdges(PlanarGenType t, int n);

// Gera um grafo planar aleatório do tipo escolhido (com seed determinística)
void generateSingle(PlanarGenType t, ogdf::Graph &G, int n, int m, std::uint32_t seed);

// Gera o dataset completo e escreve manifest.csv dentro de outDir
GenerationStats generateDataset(const GenerationConfig &cfg);

} // namespace mis::gen
