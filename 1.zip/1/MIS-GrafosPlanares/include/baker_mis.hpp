#pragma once

#include <ogdf/basic/Graph.h>

#include <cstdint>
#include <vector>
#include <unordered_set>

class BakerMIS {
public:
    // - Parâmetros do algoritmo de Baker
    struct Params { 
        int k = 4; // k >= 1 (quanto maior, melhor aproximação, mais caro)
        // mantido por compatibilidade (na rotina exata atual nao ha limite artificial)
        int maxFrontierSizeAllowed = 28;
    };

    // Retorna conjunto independente como IDs (compatível com seu pipeline do Chiba)
    // atalho: usa Params padrão
    static std::vector<int> run(const ogdf::Graph &G, const ogdf::NodeArray<int> &idsOrig);

    // versão configurável
    static std::vector<int> run(const ogdf::Graph &G,
                                const ogdf::NodeArray<int> &idsOrig,
                                const Params &p);


private:
    // ====== Etapa "Baker": embedding + níveis + remover classe ======

    // - Função que calula o conjunto de níveis do grafo
    static bool computePlanarLevels(const ogdf::Graph &G,
                                    const ogdf::NodeArray<int> &idsOrig,
                                    std::vector<int> &levelById,
                                    std::vector<std::vector<int>> &rotationById,
                                    std::unordered_set<std::uint64_t> &outerDartsById);

    static bool computePlanarLevels(const ogdf::Graph &G,
                                ogdf::NodeArray<int> &idsOrig,
                                std::vector<int> &levelById)
    {
        std::vector<std::vector<int>> dummyRotation;
        std::unordered_set<size_t> dummyOuter;
        return computePlanarLevels(G, idsOrig, levelById, dummyRotation, dummyOuter);
    }
                                
    
    // - Função que cria adjacência por IDS (estrutura auxiliar )                              
    static void buildAdjacencyById(const ogdf::Graph &G,
                                   const ogdf::NodeArray<int> &idsOrig,
                                   std::vector<std::vector<int>> &adj);

    // - Função que retorna os componentes conexos do subgrafo induzido
    static void connectedComponentsInduced(const std::vector<std::vector<int>> &adj,
                                           const std::vector<char> &active,
                                           std::vector<std::vector<int>> &comps);

    // ====== Sub-rotina exata em k-outerplanar: MIS via slices/spokes (Baker) ======
    // - Função que resolve o MIS exatamente no subgrafo k-Externoplanar
    static std::vector<int> solveMIS_kOuterplanar_exact_TW(const std::vector<std::vector<int>> &adj,
                                                          const std::vector<int> &component,
                                                          const std::vector<std::vector<int>> &rotationById,
                                                          const std::unordered_set<std::uint64_t> &outerDartsById,
                                                          const Params &p);

    static std::vector<int> solveMIS_kOuterplanar_exact_TW(std::vector<std::vector<int>> &adj,
                                                      const std::vector<int> &comp,
                                                      const Params &p)
    {
        // Compatibilidade: sem embedding induzido explícito, chama a versão nova com estruturas vazias.
        // Obs: isso NÃO é o caminho "mais fiel"; o caminho fiel é passar rotationById/outerDartsById.
        std::vector<std::vector<int>> dummyRotation;
        std::unordered_set<size_t> dummyOuter;
        return solveMIS_kOuterplanar_exact_TW(adj, comp, dummyRotation, dummyOuter, p);
    }

};