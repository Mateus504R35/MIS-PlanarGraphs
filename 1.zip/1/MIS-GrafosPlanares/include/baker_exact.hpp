#pragma once

#include <cstdint>
#include <unordered_set>
#include <vector>

namespace baker_exact {

// Dados mínimos para garantir que a rotina exata opere sobre o embedding
// induzido do embedding global do PTAS (Baker), sem re-embedar componentes.
struct InducedEmbeddingData {
    // Para cada vértice local u (0..n_local-1), lista cíclica de vizinhos
    // em ordem de embedding (rotação). Deve conter apenas vizinhos presentes
    // no componente, e idealmente conter todos eles.
    std::vector<std::vector<int>> rotation;

    // Conjunto de "darts" (u->v) que pertencem ao ciclo da face externa
    // herdada do embedding global, já em índices locais.
    std::unordered_set<std::uint64_t> outerDarts;
};

// Resolve MIS exatamente no componente k-outerplanar, usando APENAS o embedding
// induzido fornecido (rotation + outerDarts). Não re-embeda.
std::vector<int> solveExactMIS(const std::vector<std::vector<int>> &adj,
                               const std::vector<int> &component,
                               const InducedEmbeddingData &emb);

} // namespace baker_exact