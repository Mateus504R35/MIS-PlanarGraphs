#pragma once

#include <filesystem>
#include <string>
#include <vector>
#include <ogdf/basic/Graph.h>

namespace utils{
    enum class DatasetKind { RomePlanar, RandomPlanar };

    struct DatasetPaths {
        std::filesystem::path romeDir   = "datasets/rome_planar_only/rome";
        std::filesystem::path randomDir = "datasets/planar_rand";
    };

    std::vector<std::filesystem::path> listDatasetFiles(
        DatasetKind kind,
        const DatasetPaths& paths = {},
        bool recursive = true
    );

    bool readGraphFromFile(
        const std::filesystem::path& file,
        ogdf::Graph& G,
        std::string* errMsg = nullptr
    );

    void mainMenu();
    void approximationTest();
    void romePerformanceTest();
    void randomPerformanceTest();

}