/*
    - Utilidades para o programa
*/

#include "utils.hpp"
#include <filesystem>
#include <chrono>
#include <iostream>
#include <string>
#include <algorithm>
#include <cstdlib>
#include <fstream>
#include <vector>
#include <cctype>

// OGDF
#include <ogdf/basic/Graph.h>
#include <ogdf/fileformats/GraphIO.h>

using namespace std;
namespace fs = std::filesystem;

namespace {

    // - Função de transformar em minúsculo
    static std::string toLower(std::string s) {
        for (char &ch : s) ch = (char)std::tolower((unsigned char)ch);
        return s;
    }

    // - Verificar se a saída de arquivo é válida
    static bool hasAllowedExt(const fs::path& p, const std::vector<std::string>& extsLower) {
        std::string e = toLower(p.extension().string());
        for (const auto& ok : extsLower) {
            if (e == ok) return true;
        }
        return false;
    }

    // - Coletar arquivos de grafos de um dado diretório
    static std::vector<fs::path> listFilesByExt(const fs::path& dir,
                                                const std::vector<std::string>& extsLower,
                                                bool recursive) {
        std::vector<fs::path> files;

        if (!fs::exists(dir)) return files;

        if (recursive) {
            for (const auto& entry : fs::recursive_directory_iterator(dir)) {
                if (!entry.is_regular_file()) continue;
                const fs::path p = entry.path();
                if (hasAllowedExt(p, extsLower)) files.push_back(p);
            }
        } else {
            for (const auto& entry : fs::directory_iterator(dir)) {
                if (!entry.is_regular_file()) continue;
                const fs::path p = entry.path();
                if (hasAllowedExt(p, extsLower)) files.push_back(p);
            }
        }

        std::sort(files.begin(), files.end());
        return files;
    }

    // - Lê manifest.csv do dataset random e pega só as linhas status=ok
    static std::vector<fs::path> listFromManifest(const fs::path& randomDir) {
        std::vector<fs::path> files;
        const fs::path manifestPath = randomDir / "manifest.csv";

        if (!fs::exists(manifestPath)) return files;

        std::ifstream in(manifestPath);
        if (!in) return files;

        std::string line;
        // header
        std::getline(in, line);

        while (std::getline(in, line)) {
            // esperamos: status,...,file
            // pega só "ok,"
            if (line.rfind("ok,", 0) != 0) continue;

            // arquivo é o último campo -> pega após a última vírgula
            const size_t pos = line.rfind(',');
            if (pos == std::string::npos) continue;

            std::string fileStr = line.substr(pos + 1);
            // trim básico
            while (!fileStr.empty() && (fileStr.back() == '\r' || fileStr.back() == ' ')) fileStr.pop_back();
            while (!fileStr.empty() && (fileStr.front() == ' ')) fileStr.erase(fileStr.begin());

            fs::path p(fileStr);

            // se vier relativo, resolve relativo ao randomDir
            if (p.is_relative()) p = randomDir / p;

            if (fs::exists(p) && fs::is_regular_file(p)) {
                files.push_back(p);
            }
        }

        std::sort(files.begin(), files.end());
        return files;
    }

} // namespace

namespace utils {

    // - Função de implementação do menu principal do programa
    void mainMenu(){
        int op = 0;

        do{
            cout << "__________________________________________________________" << endl;
            cout << "" << endl;
            cout << "                   MIS - PLANAR GRAPHS                    " << endl;
            cout << "__________________________________________________________" << endl;
            cout << "" << endl;
            cout << "--Choose an option: " << endl;
            cout << "[1] - Algorithms Approximation Test (using Rome benchmark)" << endl;
            cout << "[2] - Algorithms Performance Test (time complexity)" << endl;
            cout << "[3] - Exit" << endl;
            cout << "-:";
            cin >> op;

            switch (op){
                case 1:
                    system("clear");
                    // approximationTest();
                    break;

                case 2:
                    system("clear");
                    // performanceTest();
                    break;

                case 3:
                    system("clear");
                    cout << "..." << endl;
                    break;

                default:
                    system("clear");
                    cout << "Error: Invalid option" << endl;
            }
        } while(op != 3);
    }

    // - Função de execução do teste de Aproximação
    void approximationTest(){
        utils::DatasetPaths p;
        auto files = utils::listDatasetFiles(utils::DatasetKind::RomePlanar, p, /*recursive=*/true);

        for (const auto& f : files) {
            ogdf::Graph G;
            std::string err;
            if (!utils::readGraphFromFile(f, G, &err)) {
                std::cerr << err << "\n";
                continue;
            }

            // roda algoritmo / mede qualidade
        }

    }

// - Função de execução do teste de Performance de Tempo no dataset Rome
    void romePerformanceTest(){
        utils::DatasetPaths p;
        auto files = utils::listDatasetFiles(utils::DatasetKind::RomePlanar, p, /*recursive=*/true);

        for (const auto& f : files) {
            ogdf::Graph G;
            std::string err;
            if (!utils::readGraphFromFile(f, G, &err)) {
                std::cerr << err << "\n";
                continue;
            }

            // roda algoritmo / mede qualidade
        }

    }

    // - Função de execução do teste de Performance de Tempo no dataset Random
    void randomPerformanceTest(){
        utils::DatasetPaths p;
        auto files = utils::listDatasetFiles(utils::DatasetKind::RandomPlanar, p, /*recursive=*/true);

        for (const auto& f : files) {
            ogdf::Graph G;
            std::string err;
            if (!utils::readGraphFromFile(f, G, &err)) {
                std::cerr << err << "\n";
                continue;
            }

            // roda algoritmo / mede qualidade
        }

    }

    // - Função de coleta de todo um dataset de grafos planares (Random ou Rome)
    std::vector<fs::path> listDatasetFiles(DatasetKind kind,
                                          const DatasetPaths& paths,
                                          bool recursive) {
        if (kind == DatasetKind::RomePlanar) {
            // Rome planar only: você disse que é .graphml
            const std::vector<std::string> exts = {".graphml"};
            return listFilesByExt(paths.romeDir, exts, recursive);
        }

        // Random planar: tenta manifest.csv primeiro (melhor)
        {
            auto fromManifest = listFromManifest(paths.randomDir);
            if (!fromManifest.empty()) return fromManifest;
        }

        // fallback: varre por extensões comuns
        const std::vector<std::string> exts = {".gml", ".graphml", ".dot", ".gexf"};
        return listFilesByExt(paths.randomDir, exts, recursive);
    }

    // - Função que valida se um grafo pode ser lido de um dado arquivo
    bool readGraphFromFile(const fs::path& file, ogdf::Graph& G, std::string* errMsg) {
        G.clear();

        const bool ok = ogdf::GraphIO::read(G, file.string());
        if (!ok && errMsg) {
            *errMsg = "GraphIO::read failed for file: " + file.string();
        }
        return ok;
    }

} // namespace utils
