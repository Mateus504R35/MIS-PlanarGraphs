#include "baker_exact.hpp"


#include <algorithm>
#include <array>
#include <cassert>
#include <climits>
#include <cstdint>
#include <deque>
#include <functional>
#include <map>
#include <queue>
#include <set>
#include <stdexcept>
#include <unordered_map>
#include <unordered_set>
#include <vector>

namespace baker_exact {
namespace {

template <typename T>
class cyclic_vector : public std::vector<T> {
public:
    T &operator[](int x) {
        while (x < 0 && !this->empty()) {
            x += (int)this->size();
        }
        if (this->empty()) {
            throw std::out_of_range("cyclic_vector");
        }
        x %= (int)this->size();
        return this->at((size_t)x);
    }

    const T &operator[](int x) const {
        while (x < 0 && !this->empty()) {
            x += (int)this->size();
        }
        if (this->empty()) {
            throw std::out_of_range("cyclic_vector");
        }
        x %= (int)this->size();
        return this->at((size_t)x);
    }
};

struct Edge {
    int u = -1;
    int v = -1;
};

struct HalfEdge {
    int edge = -1;
    int u = -1;
    int v = -1;
};

struct EdgeRef {
    int edge = -1;
    int source = -1;
    int target = -1;
};

using Embedding = std::vector<cyclic_vector<HalfEdge>>;

static inline std::uint64_t edgeKey(int a, int b) {
    if (a > b) std::swap(a, b);
    return (static_cast<std::uint64_t>(static_cast<unsigned int>(a)) << 32) |
           static_cast<unsigned int>(b);
}

static inline int otherEndpoint(const Edge &e, int v) {
    return (e.u == v) ? e.v : e.u;
}

static inline int otherEndpoint(const HalfEdge &e, int v) {
    return (e.u == v) ? e.v : e.u;
}

struct BakerGraph {
    int n = 0;
    std::vector<Edge> edges;
    Embedding embedding;
    std::vector<std::vector<int>> adjEdges; // edge ids
    std::unordered_set<std::uint64_t> edgeSet;
    std::unordered_map<std::uint64_t, int> anyEdgeId;
    std::set<std::pair<int, int>> addedEdges;

    explicit BakerGraph(int n_) : n(n_), embedding(n_), adjEdges(n_) {}

    int addEdge(int u, int v, bool markAdded) {
        int id = (int)edges.size();
        edges.push_back(Edge{u, v});
        if (u >= 0 && u < n) adjEdges[u].push_back(id);
        if (v >= 0 && v < n) adjEdges[v].push_back(id);
        auto key = edgeKey(u, v);
        edgeSet.insert(key);
        anyEdgeId[key] = id;
        if (markAdded) {
            if (u > v) std::swap(u, v);
            addedEdges.emplace(u, v);
        }
        return id;
    }

    int getAnyEdgeId(int u, int v) const {
        auto key = edgeKey(u, v);
        auto it = anyEdgeId.find(key);
        if (it == anyEdgeId.end()) return -1;
        return it->second;
    }

    bool hasEdge(int u, int v) const {
        return edgeSet.find(edgeKey(u, v)) != edgeSet.end();
    }
};

static bool check_for_edge(int x, int y, const BakerGraph &g, const std::set<std::pair<int, int>> &addedEdges) {
    if (x == y) return false;
    if (!g.hasEdge(x, y)) return false;
    int a = x, b = y;
    if (a > b) std::swap(a, b);
    return addedEdges.find(std::make_pair(a, b)) == addedEdges.end();
}

static int get_edge_it(const Embedding &embedding, int v, int w) {
    if (v < 0 || v >= (int)embedding.size()) return -1;
    const auto &edges = embedding[v];
    for (int i = 0; i < (int)edges.size(); i++) {
        int other = otherEndpoint(edges[i], v);
        if (other == w) return i;
    }
    return -1;
}

static int get_edge_it_edgeid(const Embedding &embedding, int v, int edgeId) {
    if (v < 0 || v >= (int)embedding.size()) return -1;
    const auto &edges = embedding[v];
    for (int i = 0; i < (int)edges.size(); i++) {
        if (edges[i].edge == edgeId) return i;
    }
    return -1;
}

static int get_edge_it(const Embedding &embedding, int v, const EdgeRef &e) {
    if (e.edge >= 0) return get_edge_it_edgeid(embedding, v, e.edge);
    return get_edge_it(embedding, v, e.source == v ? e.target : e.source);
}

struct FaceGetter {
    std::vector<std::vector<int>> &faces;
    std::vector<std::vector<int>> &vertices_in_face;
    int current_face = 0;

    explicit FaceGetter(std::vector<std::vector<int>> &f,
                        std::vector<std::vector<int>> &o)
        : faces(f), vertices_in_face(o) {}

    void begin_traversal() {}

    void begin_face() {
        vertices_in_face.emplace_back();
    }

    void end_face() {
        current_face++;
    }

    void next_edge(int edgeId) {
        if (edgeId >= 0 && edgeId < (int)faces.size()) {
            faces[edgeId].push_back(current_face);
        }
    }

    void next_vertex(int v) {
        vertices_in_face[current_face].push_back(v);
    }
};

template <typename Visitor>
static void level_face_traversal(const BakerGraph &g, Embedding &embedding, Visitor &visitor) {
    visitor.begin_traversal();

    std::vector<std::array<int, 2>> nextEdge(g.edges.size(), {{-1, -1}});
    std::vector<std::array<char, 2>> visited(g.edges.size(), {{0, 0}});
    std::vector<int> edges_cache;

    for (int v = 0; v < (int)embedding.size(); v++) {
        auto &edges = embedding[v];
        if (edges.empty()) continue;
        for (int i = 0; i < (int)edges.size(); i++) {
            int e = edges[i].edge;
            if (e < 0 || e >= (int)g.edges.size()) continue;
            edges_cache.push_back(e);
            int idx = (g.edges[e].u == v) ? 0 : 1;
            int nextId = edges[(i + 1) % edges.size()].edge;
            nextEdge[e][idx] = nextId;
        }
    }

    for (int e : edges_cache) {
        if (e < 0 || e >= (int)g.edges.size()) continue;
        int ends[2] = {g.edges[e].u, g.edges[e].v};
        for (int t = 0; t < 2; t++) {
            int v = ends[t];
            int idx = (g.edges[e].u == v) ? 0 : 1;
            if (visited[e][idx]) continue;
            visitor.begin_face();
            int currEdge = e;
            int currV = v;
            while (true) {
                int currIdx = (g.edges[currEdge].u == currV) ? 0 : 1;
                if (visited[currEdge][currIdx]) break;
                visitor.next_vertex(currV);
                visitor.next_edge(currEdge);
                visited[currEdge][currIdx] = 1;
                currV = otherEndpoint(g.edges[currEdge], currV);
                int next = nextEdge[currEdge][(g.edges[currEdge].u == currV) ? 0 : 1];
                if (next < 0) break;
                currEdge = next;
            }
            visitor.end_face();
        }
    }
}

template <typename Problem>
struct Tree {
    Tree<Problem> *enclosing_tree = nullptr;
    int enclosing_face = -1;
    std::vector<Problem> t;
    int root = -1;
    int outer_face = -1;
    int level = 0;

    Tree() = default;

    explicit Tree(int size, int l) : level(l) {
        t.reserve(size);
        for (int i = 0; i < size; i++) {
            t.emplace_back(l, this);
        }
    }

    Tree(const Tree<Problem> &other) {
        t = other.t;
        enclosing_tree = other.enclosing_tree;
        enclosing_face = other.enclosing_face;
        root = other.root;
        outer_face = other.outer_face;
        level = other.level;
        for (auto &p : t) {
            p.my_tree = this;
            if (!p.component_tree.empty()) {
                p.component_tree.enclosing_tree = this;
            }
        }
    }

    Tree<Problem> &operator=(const Tree<Problem> &other) {
        if (this == &other) return *this;
        t = other.t;
        enclosing_tree = other.enclosing_tree;
        enclosing_face = other.enclosing_face;
        root = other.root;
        outer_face = other.outer_face;
        level = other.level;
        for (auto &p : t) {
            p.my_tree = this;
            if (!p.component_tree.empty()) {
                p.component_tree.enclosing_tree = this;
            }
        }
        return *this;
    }

    Problem &operator[](int x) { return t[x]; }

    int size() const { return (int)t.size(); }

    bool empty() const { return t.empty(); }

    void emplace_back() { t.emplace_back(level, this); }

    Problem &get_enclosing_face() { return enclosing_tree->t[enclosing_face]; }

    const Problem &get_enclosing_face() const { return enclosing_tree->t[enclosing_face]; }

    int merge(Tree<Problem> &t2, std::map<int, int> &place_in_comp, int starting_node) {
        int s = size();
        for (int i = 0; i < t2.size(); i++) {
            t.push_back(t2[i]);
            t.back().my_tree = this;

            for (int &c : t.back().children) {
                c += s;
            }

            t.back().parent += s;
        }

        int target = 0;
        int t2_v_root = t2[t2.root].label.first;
        std::queue<int> q;
        q.push(starting_node);

        while (!q.empty()) {
            int i = q.front();
            q.pop();

            if (std::find(t[i].face.begin(), t[i].face.end(), t2_v_root) != t[i].face.end()) {
                target = i;
                break;
            }

            for (int c : t[i].children) {
                q.push(c);
            }
        }

        int t2_place = 0;
        for (int child : t2[t2.root].children) {
            if (t2[child].label.second != t2_v_root) {
                t2_place = place_in_comp[t2[child].label.second];
                break;
            }
        }

        int child_num = 0;
        for (int i = 0; i < (int)t[target].children.size(); i++) {
            if (t[t[target].children[i]].label.second == t2_v_root) {
                int t1_place = INT16_MAX;

                if (i < (int)t[target].children.size() - 1 &&
                    t[t[target].children[i + 1]].label.first == t[t[target].children[i + 1]].label.second) {
                    for (int child : t[t[target].children[i + 1]].children) {
                        if (t[child].label.second != t2_v_root) {
                            t1_place = place_in_comp[t[child].label.second];
                            break;
                        }
                    }
                }

                if (t2_place < t1_place) {
                    child_num = i + 1;
                    break;
                }
            } else if (t[t[target].children[i]].label.first == t2_v_root) {
                child_num = i;
                break;
            }
        }

        int t1_place = 0;
        for (int child : t[target].children) {
            if (t[child].label.second != t[target].label.first) {
                t1_place = place_in_comp[t[child].label.second];
                break;
            }
        }

        if (t[target].label.first == t[target].label.second && child_num == 0 && t1_place < t2_place) {
            t[target].children.push_back(s + t2.root);
        } else {
            t[target].children.insert(t[target].children.begin() + child_num, s + t2.root);
        }

        t[s + t2.root].parent = target;

        return s + t2.root;
    }

    void remove_outer_face() {
        for (auto &p : t) {
            for (int &child : p.children) {
                if (child > outer_face) {
                    child--;
                }
            }
        }

        t.erase(t.begin() + outer_face);

        if (root > outer_face) {
            root--;
        }
    }
};

struct NodeBase {
    int parent = -1;
    std::pair<int, int> label = {-1, -1};
    int LB = -1;
    int RB = -1;
    std::vector<int> children;
    std::vector<int> face;
};

struct IndependentSet : NodeBase {
    Tree<IndependentSet> *my_tree = nullptr;
    Tree<IndependentSet> component_tree;
    std::vector<std::vector<int>> val;
    int level = 0;

    IndependentSet(int l = 0, Tree<IndependentSet> *mt = nullptr)
        : my_tree(mt), val(1 << l, std::vector<int>(1 << l)), level(l) {
        if (l == 1) {
            val[0][0] = 0;
            val[0][1] = 1;
            val[1][0] = 1;
            val[1][1] = -INT16_MAX;
        }
    }

    IndependentSet(const IndependentSet &two) : my_tree(two.my_tree) {
        parent = two.parent;
        label = two.label;
        LB = two.LB;
        RB = two.RB;
        children = two.children;
        face = two.face;
        val = two.val;
        component_tree = two.component_tree;
        level = two.level;
    }

    IndependentSet &operator=(const IndependentSet &two) {
        if (this == &two) return *this;
        parent = two.parent;
        label = two.label;
        LB = two.LB;
        RB = two.RB;
        children = two.children;
        face = two.face;
        val = two.val;
        component_tree = two.component_tree;
        my_tree = two.my_tree;
        level = two.level;
        return *this;
    }

    IndependentSet &get_child(int x) { return my_tree->t[children[x]]; }

    void get_left_boundary(std::vector<int> &lb) {
        lb.push_back(label.first);
        if (my_tree->enclosing_tree == nullptr) return;
        auto &children_ref = my_tree->enclosing_tree->t[my_tree->enclosing_face].children;
        int child = LB;
        if (LB >= (int)children_ref.size()) {
            child--;
        }
        my_tree->enclosing_tree->t[children_ref[child]].get_left_boundary(lb);
    }

    void get_right_boundary(std::vector<int> &rb) {
        rb.push_back(label.second);
        if (my_tree->enclosing_tree == nullptr) return;
        my_tree->enclosing_tree->t[my_tree->enclosing_tree->t[my_tree->enclosing_face].children[RB - 1]]
            .get_right_boundary(rb);
    }

    void merge(const std::vector<std::vector<int>> &one, const std::vector<std::vector<int>> &two) {
        int count = 1 << level;
        for (int u = 0; u < count; u++) {
            for (int v = 0; v < count; v++) {
                val[u][v] = -INT16_MAX;
                for (int z = 0; z < count; z++) {
                    int ones = 0;
                    for (int i = 0; i < level; i++) {
                        ones += (z & (1 << i)) > 0;
                    }
                    val[u][v] = std::max(val[u][v], one[u][z] + two[z][v] - ones);
                }
            }
        }
    }

    void adjust(const BakerGraph &g, const std::set<std::pair<int, int>> &ae) {
        int count = 1 << (level - 1);

        if (label.first == label.second) {
            for (int u = 0; u < count; u++) {
                for (int v = 0; v < count; v++) {
                    val[(u << 1) + 1][(v << 1) + 1]--;
                    val[u << 1][(v << 1) + 1] = -INT16_MAX;
                    val[(u << 1) + 1][v << 1] = -INT16_MAX;
                }
            }
        }
        if (check_for_edge(label.first, label.second, g, ae)) {
            for (int u = 0; u < count; u++) {
                for (int v = 0; v < count; v++) {
                    val[(u << 1) + 1][(v << 1) + 1] = -INT16_MAX;
                }
            }
        }
    }

    void contract(const IndependentSet &two) {
        int count = 1 << level;
        for (int u = 0; u < count; u++) {
            for (int v = 0; v < count; v++) {
                val[u][v] = std::max(two.val[(u << 1) + 1][(v << 1) + 1], two.val[u << 1][v << 1]);
            }
        }
    }

    IndependentSet extend(int z, const BakerGraph &g, const std::set<std::pair<int, int>> &ae) {
        int count = 1 << level;
        IndependentSet res(level + 1);

        std::vector<int> lb;
        std::vector<int> rb;
        get_left_boundary(lb);
        get_right_boundary(rb);

        for (int u = 0; u < count; u++) {
            for (int v = 0; v < count; v++) {
                res.val[u << 1][v << 1] = val[u][v];
                res.val[u << 1][(v << 1) + 1] = -INT16_MAX;
                res.val[(u << 1) + 1][v << 1] = -INT16_MAX;

                if (((u & 1) == 1 && check_for_edge(lb[0], z, g, ae)) ||
                    ((v & 1) == 1 && check_for_edge(rb[0], z, g, ae))) {
                    res.val[(u << 1) + 1][(v << 1) + 1] = -INT16_MAX;
                } else {
                    res.val[(u << 1) + 1][(v << 1) + 1] = val[u][v] + 1;
                }
            }
        }

        return res;
    }

    void create(int child_num, const BakerGraph &g, const std::set<std::pair<int, int>> &ae) {
        const std::vector<int> &children_ref = my_tree->enclosing_tree->t[my_tree->enclosing_face].children;
        std::vector<int> vertices;

        if (child_num < (int)children_ref.size()) {
            IndependentSet &child = my_tree->enclosing_tree->t[children_ref[child_num]];
            child.get_left_boundary(vertices);
        } else {
            IndependentSet &child = my_tree->enclosing_tree->t[children_ref[child_num - 1]];
            child.get_right_boundary(vertices);
        }

        int count = 1 << (int)vertices.size();

        for (int u = 0; u < (count << 1); u++) {
            for (int v = 0; v < (count << 1); v++) {
                val[u][v] = -INT16_MAX;
            }
        }

        for (int i = 0; i < count; i++) {
            bool bad = false;
            for (int v = 0; v < (int)vertices.size() - 1; v++) {
                if (((i >> v) & 1) && ((i >> (v + 1)) & 1) &&
                    check_for_edge(vertices[v], vertices[v + 1], g, ae)) {
                    bad = true;
                    break;
                }
            }

            if (bad) {
                continue;
            }

            int ones = 0;
            for (int j = 0; j < (int)vertices.size(); j++) {
                ones += (i & (1 << j)) > 0;
            }

            val[i << 1][i << 1] = ones;

            if ((i & 1) == 0 || !check_for_edge(vertices[0], label.first, g, ae)) {
                val[(i << 1) + 1][i << 1] = ones + 1;
            }

            if ((i & 1) == 0 || !check_for_edge(vertices[0], label.second, g, ae)) {
                val[i << 1][(i << 1) + 1] = ones + 1;
            }

            if ((i & 1) == 0 || (!check_for_edge(vertices[0], label.second, g, ae) &&
                                 !check_for_edge(vertices[0], label.first, g, ae))) {
                val[(i << 1) + 1][(i << 1) + 1] = ones + 2;
            }
        }
    }

    int result() const {
        if (val.empty()) return 0;
        return std::max(val[0][0], val[1][1]);
    }
};

static int popcount_mask(int mask, int level) {
    int ones = 0;
    for (int i = 0; i < level; i++) {
        ones += (mask & (1 << i)) > 0;
    }
    return ones;
}

static std::vector<std::vector<int>> merge_tables(const std::vector<std::vector<int>> &one,
                                                   const std::vector<std::vector<int>> &two,
                                                   int level) {
    int count = 1 << level;
    std::vector<std::vector<int>> out(count, std::vector<int>(count, -INT16_MAX));
    for (int u = 0; u < count; u++) {
        for (int v = 0; v < count; v++) {
            int best = -INT16_MAX;
            for (int z = 0; z < count; z++) {
                int val = one[u][z] + two[z][v] - popcount_mask(z, level);
                if (val > best) best = val;
            }
            out[u][v] = best;
        }
    }
    return out;
}

struct TreeBuilder {
    const std::vector<std::vector<int>> &faces;
    Tree<IndependentSet> &tree;
    const BakerGraph &graph;
    int current_face = 0;
    int last_vertex = -1;

    TreeBuilder(const std::vector<std::vector<int>> &f, Tree<IndependentSet> &t, const BakerGraph &g)
        : faces(f), tree(t), graph(g) {}

    void begin_traversal() {}

    void begin_face() {
        if (current_face >= 0 && current_face < tree.size()) {
            tree[current_face].face.clear();
        }
    }

    void end_face() {
        current_face++;
    }

    void next_vertex(int v) {
        tree[current_face].face.push_back(v);
        last_vertex = v;
    }

    void next_edge(int edgeId) {
        if (current_face == tree.outer_face) return;
        if (edgeId < 0 || edgeId >= (int)graph.edges.size()) return;
        if (faces[edgeId].size() < 2) return;

        int neighbor = (faces[edgeId][0] == current_face) ? faces[edgeId][1] : faces[edgeId][0];

        if (neighbor == tree.outer_face) {
            tree.emplace_back();
            int last = tree.size() - 1;
            tree[current_face].children.push_back(last);
            tree[last].parent = current_face;
            int u = graph.edges[edgeId].u;
            int v = graph.edges[edgeId].v;
            tree[last].label.second = last_vertex;
            tree[last].label.first = (last_vertex == u) ? v : u;
        } else {
            tree[current_face].children.push_back(neighbor);
        }
    }
};

class BakerImpl {
public:
    BakerImpl(BakerGraph &g, Embedding &emb, const std::vector<int> &outer_face)
        : graph(g), embedding(emb), outerFace(outer_face), vertexLevel(g.n, -1) {}

    std::vector<int> solve() {
        std::vector<std::vector<int>> outer_edges;
        int max_level = name_levels(outerFace, vertexLevel, outer_edges);
        (void)max_level;

        int v_root = 0;
        for (int i = 0; i < (int)vertexLevel.size(); i++) {
            if (vertexLevel[i] == 1) {
                v_root = i;
                break;
            }
        }

        tree = build_tree_with_dividing_points(outerFace, v_root);
        create_boudaries(tree, tree, tree.root);
        table(tree, tree.root);

        int rootMask = (tree[tree.root].val[0][0] >= tree[tree.root].val[1][1]) ? 0 : 1;
        std::vector<int> selected;
        reconstruct_node(tree, tree.root, rootMask, rootMask, selected);
        std::sort(selected.begin(), selected.end());
        selected.erase(std::unique(selected.begin(), selected.end()), selected.end());
        return selected;
    }

private:
    BakerGraph &graph;
    Embedding &embedding;
    std::vector<int> outerFace;
    std::vector<int> vertexLevel;
    Tree<IndependentSet> tree;
    std::set<std::pair<int, int>> addedEdges;

    int name_levels(std::vector<int> &outer_face, std::vector<int> &vertex_level,
                    std::vector<std::vector<int>> &outer_edges) {
        for (int &v : vertex_level) v = -1;
        for (int v : outer_face) vertex_level[v] = 1;

        std::queue<EdgeRef> next_level_edges;
        outer_edges.clear();
        outer_edges.emplace_back();
        outer_edges.emplace_back();

        for (int i = 0; i < (int)outer_face.size(); i++) {
            int v = outer_face[i];
            int w = outer_face[(i + 1) % outer_face.size()];
            int eid = graph.getAnyEdgeId(v, w);
            if (eid >= 0) {
                outer_edges[1].push_back(eid);
            }
            for (const HalfEdge &he : embedding[v]) {
                int a = he.u;
                int b = he.v;
                if (vertex_level[a] == -1 || vertex_level[b] == -1) {
                    next_level_edges.push(EdgeRef{he.edge, he.u, he.v});
                }

                if (he.u == w) {
                    EdgeRef e = {he.edge, he.u, he.v};
                    std::swap(e.source, e.target);
                    int e_it = get_edge_it(embedding, w, e);
                    if (e_it >= 0) {
                        std::swap(embedding[w][e_it].u, embedding[w][e_it].v);
                    }
                }
            }
        }

        EdgeRef next_level_edge;
        EdgeRef current_edge;
        int starting_v = -1;
        int current_v = -1;
        int current_edge_it = -1;

        int level = 1;
        std::vector<int> current_level;

        while (!next_level_edges.empty()) {
            current_level.clear();
            next_level_edge = next_level_edges.front();
            next_level_edges.pop();

            if (vertex_level[next_level_edge.source] > -1 && vertex_level[next_level_edge.target] > -1) {
                continue;
            }

            level = (vertex_level[next_level_edge.source] == -1)
                        ? vertex_level[next_level_edge.target]
                        : vertex_level[next_level_edge.source];
            level++;

            starting_v = (vertex_level[next_level_edge.source] == -1)
                             ? next_level_edge.source
                             : next_level_edge.target;

            current_level.push_back(starting_v);

            current_edge_it = get_edge_it(embedding, starting_v, next_level_edge);

            vertex_level[starting_v] = level;
            bool res = false;
            for (int j = current_edge_it + 1; j < current_edge_it + (int)embedding[starting_v].size(); j++) {
                HalfEdge e_j = embedding[starting_v][j];
                if (vertex_level[e_j.u] == -1 || vertex_level[e_j.v] == -1) {
                    current_edge = EdgeRef{e_j.edge, e_j.u, e_j.v};
                    res = true;
                    break;
                }
            }
            if (!res) {
                continue;
            }

            vertex_level[starting_v] = -1;

            current_v = (current_edge.source == starting_v) ? current_edge.target : current_edge.source;
            current_edge_it = get_edge_it(embedding, current_v, current_edge);

            current_level.push_back(current_v);

            int next_to_starting_v = current_v;

            if (level >= (int)outer_edges.size()) {
                outer_edges.emplace_back();
            }

            while (true) {
                outer_edges[level].push_back(current_edge.edge);

                int temp_v = current_v;

                for (int j = current_edge_it + 1;
                     j < current_edge_it + (int)embedding[current_v].size();
                     j++) {
                    HalfEdge e_j = embedding[current_v][j];
                    int neighbour = (e_j.u == current_v) ? e_j.v : e_j.u;
                    if (vertex_level[neighbour] == -1) {
                        current_edge = EdgeRef{e_j.edge, e_j.u, e_j.v};
                        break;
                    }
                }

                current_v = (current_edge.source == current_v) ? current_edge.target : current_edge.source;
                current_edge_it = get_edge_it(embedding, current_v, current_edge);

                current_level.push_back(current_v);

                if (temp_v == starting_v && current_v == next_to_starting_v) {
                    break;
                }
            }

            current_level.pop_back();

            for (int v : current_level) {
                vertex_level[v] = level;
            }

            for (int i = 0; i < (int)current_level.size(); i++) {
                int v = current_level[i];
                int w = current_level[(i + 1) % current_level.size()];
                for (HalfEdge &he : embedding[v]) {
                    if (vertex_level[he.u] == -1 || vertex_level[he.v] == -1) {
                        next_level_edges.push(EdgeRef{he.edge, he.u, he.v});
                    }

                    if (he.u == w) {
                        EdgeRef e = {he.edge, he.u, he.v};
                        std::swap(e.source, e.target);
                        int e_it = get_edge_it(embedding, w, e);
                        if (e_it >= 0) {
                            std::swap(embedding[w][e_it].u, embedding[w][e_it].v);
                        }
                    }
                }
            }
        }

        return level;
    }

    void add_edge_emb(int a, int b, int posA, int posB, bool markAdded) {
        int edgeId = graph.addEdge(a, b, markAdded);
        if (a >= 0 && a < (int)embedding.size()) {
            embedding[a].insert(embedding[a].begin() + posA, HalfEdge{edgeId, a, b});
        }
        if (b >= 0 && b < (int)embedding.size()) {
            embedding[b].insert(embedding[b].begin() + posB, HalfEdge{edgeId, b, a});
        }
    }

    void triangulate(std::vector<int> &face, std::vector<int> &component, int turn) {
        (void)turn;
        if (component.size() == 1) {
            int c = component[0];
            embedding[c].clear();

            for (int i = 0; i < (int)face.size(); i++) {
                int v = face[i];

                bool existed = graph.hasEdge(v, c);
                int eid = graph.getAnyEdgeId(v, c);
                if (!existed || eid < 0) {
                    eid = graph.addEdge(c, v, true);
                    int a = v, b = c;
                    if (a > b) std::swap(a, b);
                    addedEdges.emplace(a, b);
                }
                embedding[c].push_back(HalfEdge{eid, v, c});

                if (!existed) {
                    int next = face[(i + 1) % face.size()];
                    int pos = get_edge_it(embedding, v, next);
                    if (pos < 0) pos = 0;
                    embedding[v].insert(embedding[v].begin() + pos + 1, HalfEdge{eid, v, c});
                }
            }
            return;
        }

        int level = vertexLevel[face[0]];
        EdgeRef connecting_e;
        int starting_v = -1;
        int starting_v_it = -1;
        int c_v = -1;

        for (int i = 0; i < (int)face.size(); i++) {
            int v = face[i];
            for (const HalfEdge &he : embedding[v]) {
                int neighbour = (he.u == v) ? he.v : he.u;
                if (std::find(component.begin(), component.end(), neighbour) != component.end()) {
                    connecting_e = EdgeRef{he.edge, he.u, he.v};
                    starting_v = v;
                    starting_v_it = i;
                    c_v = neighbour;
                    break;
                }
            }
            if (starting_v_it > -1) break;
        }

        std::rotate(face.begin(), face.begin() + starting_v_it, face.end());
        std::rotate(component.begin(), std::find(component.begin(), component.end(), c_v), component.end());

        int face_it = 0;
        int comp_it = 0;
        int curr_e_it_face = get_edge_it(embedding, starting_v, connecting_e);
        int curr_e_it_comp = get_edge_it(embedding, c_v, connecting_e);

        std::set<int> comp_vis;
        std::set<int> face_vis;

        int comp = 0;

        while (comp < (int)component.size() || face_vis.size() < face.size()) {
            bool res = false;
            int comp_curr = component[comp_it];
            int face_curr = face[face_it];
            int last = -1;

            face_vis.insert(face_curr);

            int first_e =
                get_edge_it(embedding, comp_curr,
                            component[(comp_it - 1 + component.size()) % component.size()]);
            int second_e =
                get_edge_it(embedding, comp_curr,
                            component[(comp_it + 1) % component.size()]);

            for (int i = (first_e + 1) % embedding[comp_curr].size(); i != second_e;
                 i = (i + 1) % embedding[comp_curr].size()) {
                if (i == curr_e_it_comp) {
                    res = true;
                    break;
                }
            }

            if (!res) {
                curr_e_it_comp = first_e;
            }

            res = false;

            for (int i = (curr_e_it_comp + 1) % embedding[comp_curr].size(); i != second_e;
                 i = (i + 1) % embedding[comp_curr].size()) {
                HalfEdge &e = embedding[comp_curr][i];
                int neighbour = (e.u == comp_curr) ? e.v : e.u;
                if (vertexLevel[neighbour] == level && neighbour != face_curr) {
                    res = true;
                    last = neighbour;
                    break;
                }
            }

            if (res) {
                for (int i = (face_it + 1) % face.size();; i = (i + 1) % face.size()) {
                    if (face[i] == last) {
                        face_it = i;
                        curr_e_it_face =
                            (get_edge_it(embedding, last, face[(i - 1 + face.size()) % face.size()]) - 1 +
                             (int)embedding[last].size()) %
                            (int)embedding[last].size();
                        curr_e_it_comp = (curr_e_it_comp + 1) % embedding[comp_curr].size();
                        break;
                    }

                    face_vis.insert(face[i]);
                    if (!graph.hasEdge(comp_curr, face[i])) {
                        int a = face[i], b = comp_curr;
                        if (a > b) std::swap(a, b);
                        addedEdges.emplace(a, b);
                    }

                    curr_e_it_comp = (curr_e_it_comp + 1) % embedding[comp_curr].size();
                    int e_it = 0;
                    if (i == face_it) {
                        e_it = curr_e_it_face;
                    } else {
                        e_it = get_edge_it(embedding, face[i], face[i - 1]);
                    }

                    HalfEdge &existing = embedding[face[i]][e_it];
                    if (existing.u != comp_curr && existing.v != comp_curr) {
                        add_edge_emb(face[i], comp_curr, e_it, curr_e_it_comp, true);
                    }
                }
            } else {
                comp_vis.insert(comp_curr);
                comp++;
                comp_it = (comp_it + 1) % component.size();
                curr_e_it_comp = get_edge_it(embedding, component[comp_it], comp_curr);
                comp_curr = component[comp_it];

                if (!graph.hasEdge(comp_curr, face_curr)) {
                    int a = face_curr, b = comp_curr;
                    if (a > b) std::swap(a, b);
                    addedEdges.emplace(a, b);
                }

                int temp_e_it_face =
                    (curr_e_it_face - 1 + (int)embedding[face_curr].size()) % (int)embedding[face_curr].size();
                int temp_e_it_comp =
                    (curr_e_it_comp + 1) % (int)embedding[comp_curr].size();

                HalfEdge &he = embedding[comp_curr][temp_e_it_comp];
                if (he.u != face_curr && he.v != face_curr) {
                    add_edge_emb(face_curr, comp_curr, curr_e_it_face, curr_e_it_comp + 1, true);
                } else {
                    curr_e_it_face = (curr_e_it_face - 1 + (int)embedding[face_curr].size()) %
                                     (int)embedding[face_curr].size();
                    for (; curr_e_it_face < (int)embedding[face_curr].size(); curr_e_it_face++) {
                        HalfEdge &edge_curr = embedding[face_curr][curr_e_it_face];
                        if (edge_curr.edge == he.edge) {
                            break;
                        }
                    }
                }
                curr_e_it_comp = (curr_e_it_comp + 1) % embedding[comp_curr].size();
            }
        }
    }

    int find_third(int one, int two, std::vector<int> &component) {
        auto &one_edges = embedding[one];
        int level = vertexLevel[one];

        if (one == two) {
            for (auto e_i : one_edges) {
                int target_i = (e_i.u == one) ? e_i.v : e_i.u;
                if (vertexLevel[target_i] == level + 1) {
                    return target_i;
                }
            }
        }

        int edge_it = get_edge_it(embedding, one, two);
        int cos = edge_it - (int)one_edges.size();
        int third = -1;
        int connecting_e_it = -1;
        for (int i = edge_it - 1; i > cos; i--) {
            HalfEdge he = one_edges[i];
            third = (he.u == one) ? he.v : he.u;
            if (third != one) {
                connecting_e_it = get_edge_it(embedding, third, one);
                break;
            }
        }

        int starting_v = third;
        component.push_back(starting_v);

        HalfEdge current_e;
        int current_v = -1;
        bool res = false;
        level++;
        auto &edges = embedding[starting_v];
        for (int i = (connecting_e_it + 1) % edges.size(); i != connecting_e_it;
             i = (i + 1) % edges.size()) {
            HalfEdge e = edges[i];
            int neighbour = (e.u == starting_v) ? e.v : e.u;

            if (vertexLevel[neighbour] == level) {
                current_e = e;
                current_v = neighbour;
                res = true;
                break;
            }
        }
        if (!res) {
            return third;
        }

        while (true) {
            component.push_back(current_v);

            int temp_v = current_v;

            int current_e_it = get_edge_it(embedding, current_v, EdgeRef{current_e.edge, current_e.u, current_e.v});
            auto &edges2 = embedding[current_v];
            int i = (current_e_it + 1 + (int)edges2.size()) % (int)edges2.size();
            res = false;
            for (; i != current_e_it; i = (i + 1 + (int)edges2.size()) % (int)edges2.size()) {
                HalfEdge e = edges2[i];
                int neighbour = (e.u == current_v) ? e.v : e.u;

                if (vertexLevel[neighbour] == level) {
                    current_e = e;
                    current_v = neighbour;
                    res = true;
                    break;
                }
            }

            if (!res) {
                HalfEdge e = edges2[current_e_it];
                int neighbour = (e.u == current_v) ? e.v : e.u;

                if (vertexLevel[neighbour] == level) {
                    current_e = e;
                    current_v = neighbour;
                }
            }

            if (temp_v == starting_v && current_v == component[1]) {
                break;
            }
        }

        component.pop_back();

        return third;
    }

    int find_dividing_points(const HalfEdge &one, const HalfEdge &two, std::set<int> &dividing_points) {
        int v = one.v;
        int level = vertexLevel[v];

        int one_it = get_edge_it(embedding, v, EdgeRef{one.edge, one.u, one.v});
        int two_it = get_edge_it(embedding, v, EdgeRef{two.edge, two.u, two.v});

        auto &edges = embedding[v];

        for (int i = (one_it + 1) % edges.size(); i != two_it; i = (i + 1) % edges.size()) {
            HalfEdge e = edges[i];
            if (vertexLevel[e.u] == level - 1 || vertexLevel[e.v] == level - 1) {
                dividing_points.insert(vertexLevel[e.u] == level - 1 ? e.u : e.v);
                return vertexLevel[e.u] == level - 1 ? e.u : e.v;
            }
        }

        return -1;
    }

    void get_leaves(Tree<IndependentSet> &t, std::vector<int> &leaves, int v) {
        if (t[v].children.empty()) {
            leaves.push_back(v);
            return;
        }

        for (auto child : t[v].children) {
            get_leaves(t, leaves, child);
        }
    }

    void get_component(std::vector<std::vector<int>> &components, std::map<int, int> &vis,
                       std::vector<std::pair<int, int>> &v_in_c) {
        if (vertexLevel[v_in_c[0].first] == 1) {
            for (int v : outerFace) {
                components[0].push_back(v);
            }
            return;
        }

        int comp_num = 0;

        for (int c = 0; c < (int)v_in_c.size(); c++) {
            if (vis.find(v_in_c[c].first) != vis.end()) {
                continue;
            }
            components.emplace_back();

            int v = v_in_c[c].first;
            int level = vertexLevel[v];
            int starting_v = v;
            int connecting_e_it = get_edge_it(embedding, v, v_in_c[c].second);

            vis[starting_v] = comp_num;
            components.back().push_back(starting_v);

            HalfEdge current_e;
            int current_v = -1;
            bool res = false;

            auto &edges = embedding[starting_v];
            for (int i = (connecting_e_it + 1) % edges.size(); i != connecting_e_it;
                 i = (i + 1) % edges.size()) {
                HalfEdge e = edges[i];
                int neighbour = (e.u == starting_v) ? e.v : e.u;

                if (vertexLevel[neighbour] == level) {
                    current_e = e;
                    current_v = neighbour;
                    res = true;
                    break;
                }
            }
            if (!res) {
                comp_num++;
                continue;
            }

            while (true) {
                vis[current_v] = comp_num;
                components.back().push_back(current_v);

                int temp_v = current_v;

                int current_e_it = get_edge_it(embedding, current_v, EdgeRef{current_e.edge, current_e.u, current_e.v});
                auto &edges2 = embedding[current_v];
                int i = (current_e_it + 1 + (int)edges2.size()) % (int)edges2.size();
                res = false;
                for (; i != current_e_it; i = (i + 1 + (int)edges2.size()) % (int)edges2.size()) {
                    HalfEdge e = edges2[i];
                    int neighbour = (e.u == current_v) ? e.v : e.u;

                    if (vertexLevel[neighbour] == level) {
                        current_e = e;
                        current_v = neighbour;
                        res = true;
                        break;
                    }
                }

                if (!res) {
                    HalfEdge e = edges2[current_e_it];
                    int neighbour = (e.u == current_v) ? e.v : e.u;

                    if (vertexLevel[neighbour] == level) {
                        current_e = e;
                        current_v = neighbour;
                    }
                }

                if (temp_v == starting_v && current_v == components.back()[1]) {
                    break;
                }
            }

            components.back().pop_back();
            comp_num++;
        }
    }

    void make_connected(std::vector<std::vector<int>> &components, std::map<int, int> &vis,
                        std::vector<std::pair<int, int>> &v_in_c) {
        std::vector<bool> connected(components.size(), false);

        for (int i = 0; i < (int)v_in_c.size(); i++) {
            int curr = v_in_c[i].first;
            int curr_con = v_in_c[i].second;
            int next = v_in_c[(i + 1) % v_in_c.size()].first;
            int next_con = v_in_c[(i + 1) % v_in_c.size()].second;

            connected[vis[curr]] = true;

            if (vis[curr] == vis[next] || graph.hasEdge(curr, next) || connected[vis[next]]) {
                continue;
            }

            int a = curr, b = next;
            if (a > b) std::swap(a, b);
            addedEdges.emplace(a, b);

            int pos_curr = get_edge_it(embedding, curr, curr_con) + 1;
            int pos_next = get_edge_it(embedding, next, next_con);
            add_edge_emb(curr, next, pos_curr, pos_next, true);
        }
    }

    void check_for_components(const std::vector<int> &face, std::vector<std::pair<int, int>> &out) {
        if (face.size() == 2) return;
        int level = vertexLevel[face[0]];
        int prev = (int)face.size() - 1, curr = 0, next = 1;

        for (; curr < (int)face.size();
             prev = (prev + 1) % face.size(), curr++, next = (next + 1) % face.size()) {
            int one = get_edge_it(embedding, face[curr], face[prev]);
            int two = get_edge_it(embedding, face[curr], face[next]);
            for (int i = (one - 1 + (int)embedding[face[curr]].size()) % (int)embedding[face[curr]].size(); i != two;
                 i = (i - 1 + (int)embedding[face[curr]].size()) % (int)embedding[face[curr]].size()) {
                HalfEdge e = embedding[face[curr]][i];
                int target = (e.u == face[curr]) ? e.v : e.u;

                if (vertexLevel[target] == level + 1) {
                    out.emplace_back(target, face[curr]);
                }
            }
        }
    }

    void root_tree_2(Tree<IndependentSet> &t, int node) {
        if (t[node].children.empty()) return;

        int parent_it = 0;
        auto child = t[node].children.begin();
        for (int i = 0; child != t[node].children.end(); child++, i++) {
            if (*child == t[node].parent) {
                t[node].children.erase(child--);
                parent_it = i;
            } else {
                t[*child].parent = node;
                root_tree_2(t, *child);
            }
        }

        int last = (int)t[node].children.size() - 1;

        std::rotate(t[node].children.begin(), t[node].children.begin() + parent_it, t[node].children.end());

        t[node].label.first = t[t[node].children[0]].label.first;
        t[node].label.second = t[t[node].children[last]].label.second;
    }

    void root_tree_with_root(Tree<IndependentSet> &t, int root) {
        int node = -1;

        for (int i = 0; i < t.size(); i++) {
            for (int v : t[i].face) {
                if (v == root) {
                    node = i;
                    break;
                }
            }
            if (node != -1) break;
        }

        t.root = node;
        root_tree_2(t, node);

        auto &children = t[node].children;

        for (int i = 0; i < (int)children.size(); i++) {
            int child = children[i];
            if (t[child].label.first == root) {
                std::rotate(t[node].children.begin(), t[node].children.begin() + i, t[node].children.end());
                break;
            }
        }

        t[node].label.first = root;
        t[node].label.second = root;
    }

    Tree<IndependentSet> build_tree(std::vector<int> component, Embedding &emb) {
        int level = vertexLevel[component[0]];

        std::vector<std::vector<int>> faces(graph.edges.size());
        std::vector<std::vector<int>> vertices_in_face;
        FaceGetter my_vis(faces, vertices_in_face);
        level_face_traversal(graph, emb, my_vis);
        Tree<IndependentSet> t(my_vis.current_face, level);

        int outer = 0;
        for (; outer < (int)vertices_in_face.size(); outer++) {
            auto &face = vertices_in_face[outer];
            int start = -1;
            for (int i = 0; i < (int)face.size(); i++) {
                if (face[i] == component[0]) {
                    start = i;
                    break;
                }
            }
            if (start == -1) continue;

            std::rotate(face.begin(), face.begin() + start, face.end());
            if (face == component) {
                break;
            }
        }

        t.outer_face = outer;
        TreeBuilder tree_b(faces, t, graph);
        level_face_traversal(graph, emb, tree_b);
        t.remove_outer_face();

        for (auto &node : t.t) {
            std::reverse(node.children.begin(), node.children.end());
            std::reverse(node.face.begin(), node.face.end());
        }

        return t;
    }

    void compute_biconnected(const std::vector<int> &component,
                             std::vector<std::vector<int>> &bicomps,
                             std::vector<std::set<int>> &v_in_bicomps,
                             std::map<std::pair<int, int>, int> &bi_map,
                             std::vector<int> &art_points) {
        int n = graph.n;
        std::vector<char> inComp(n, 0);
        for (int v : component) inComp[v] = 1;

        std::vector<std::vector<int>> simpleAdj(n);
        std::unordered_set<std::uint64_t> seen;
        for (int u : component) {
            for (int edgeId : graph.adjEdges[u]) {
                int v = otherEndpoint(graph.edges[edgeId], u);
                if (!inComp[v] || u > v) continue;
                auto key = edgeKey(u, v);
                if (!seen.insert(key).second) continue;
                simpleAdj[u].push_back(v);
                simpleAdj[v].push_back(u);
            }
        }

        std::vector<int> disc(n, -1), low(n, -1), parent(n, -1);
        std::vector<char> isArt(n, 0);
        std::vector<std::pair<int, int>> st;
        int timer = 0;
        int compId = 0;

        std::function<void(int)> dfs = [&](int u) {
            disc[u] = low[u] = ++timer;
            int children = 0;
            for (int v : simpleAdj[u]) {
                if (disc[v] == -1) {
                    parent[v] = u;
                    children++;
                    st.emplace_back(u, v);
                    dfs(v);
                    low[u] = std::min(low[u], low[v]);
                    if ((parent[u] == -1 && children > 1) || (parent[u] != -1 && low[v] >= disc[u])) {
                        isArt[u] = 1;
                        std::set<int> verts;
                        bicomps.emplace_back();
                        v_in_bicomps.emplace_back();
                        while (!st.empty()) {
                            auto e = st.back();
                            st.pop_back();
                            int a = e.first;
                            int b = e.second;
                            if (a > b) std::swap(a, b);
                            bi_map[std::make_pair(a, b)] = compId;
                            verts.insert(a);
                            verts.insert(b);
                            if (e.first == u && e.second == v) break;
                        }
                        for (int vv : verts) v_in_bicomps.back().insert(vv);
                        compId++;
                    }
                } else if (v != parent[u] && disc[v] < disc[u]) {
                    low[u] = std::min(low[u], disc[v]);
                    st.emplace_back(u, v);
                }
            }
        };

        for (int u : component) {
            if (disc[u] == -1) {
                dfs(u);
                if (!st.empty()) {
                    std::set<int> verts;
                    bicomps.emplace_back();
                    v_in_bicomps.emplace_back();
                    while (!st.empty()) {
                        auto e = st.back();
                        st.pop_back();
                        int a = e.first;
                        int b = e.second;
                        if (a > b) std::swap(a, b);
                        bi_map[std::make_pair(a, b)] = compId;
                        verts.insert(a);
                        verts.insert(b);
                    }
                    for (int vv : verts) v_in_bicomps.back().insert(vv);
                    compId++;
                }
            }
        }

        for (int i = 0; i < n; i++) {
            if (isArt[i] && inComp[i]) art_points.push_back(i);
        }
    }

    Tree<IndependentSet> build_tree_with_dividing_points(std::vector<int> component, int root) {
        int level = vertexLevel[component[0]];

        if (component.size() == 1) {
            Tree<IndependentSet> t(1, level);
            t[0].label.first = component[0];
            t[0].label.second = component[0];
            t.root = 0;
            return t;
        }

        std::vector<std::vector<int>> bicomps;
        std::vector<std::set<int>> v_in_bicomps;
        std::map<std::pair<int, int>, int> bi_map;
        std::vector<int> art_points;
        compute_biconnected(component, bicomps, v_in_bicomps, bi_map, art_points);
        int bi_num = (int)bicomps.size();

        std::vector<Tree<IndependentSet>> trees(bi_num);

        for (int i = 0; i < (int)component.size(); i++) {
            int curr = component[i];
            int next = component[(i + 1) % component.size()];
            int a = curr, b = next;
            if (a > b) std::swap(a, b);
            int idx = bi_map[std::make_pair(a, b)];
            bicomps[idx].push_back(curr);
        }

        for (auto &bic : bicomps) {
            if (bic.size() == 2) {
                int u = bic[0];
                int v = bic[1];
                int edgeId = graph.addEdge(u, v, false);
                int it = get_edge_it(embedding, u, v);
                if (it < 0) it = 0;
                embedding[u].insert(embedding[u].begin() + it, HalfEdge{edgeId, u, v});
                it = get_edge_it(embedding, v, u);
                if (it < 0) it = 0;
                embedding[v].insert(embedding[v].begin() + it, HalfEdge{edgeId, v, u});
            }
        }

        for (int i = 0; i < bi_num; i++) {
            Embedding emb(graph.n);
            for (int v : v_in_bicomps[i]) {
                for (const HalfEdge &he : embedding[v]) {
                    int a = he.u;
                    int b = he.v;
                    int aa = a, bb = b;
                    if (aa > bb) std::swap(aa, bb);
                    auto it = bi_map.find(std::make_pair(aa, bb));
                    if (it != bi_map.end() && it->second == i &&
                        vertexLevel[a] == level && vertexLevel[b] == level) {
                        emb[v].push_back(he);
                    }
                }
            }
            trees[i] = build_tree(bicomps[i], emb);
        }

        std::map<int, std::vector<int>> art_to_bicomp;
        std::map<int, std::vector<int>> bicomp_to_art;

        for (int a : art_points) {
            for (int i = 0; i < (int)v_in_bicomps.size(); i++) {
                if (v_in_bicomps[i].find(a) != v_in_bicomps[i].end()) {
                    art_to_bicomp[a].push_back(i);
                    bicomp_to_art[i].push_back(a);
                }
            }
        }

        int main_bicomp = 0;
        for (int i = 0; i < (int)v_in_bicomps.size(); i++) {
            if (v_in_bicomps[i].find(root) != v_in_bicomps[i].end()) {
                main_bicomp = i;
                break;
            }
        }

        root_tree_with_root(trees[main_bicomp], root);

        std::vector<bool> merged(bi_num, false);
        merged[main_bicomp] = true;

        std::vector<int> where_to_merge(bi_num);
        where_to_merge[main_bicomp] = trees[main_bicomp].root;

        std::queue<int> q;
        q.push(main_bicomp);

        std::map<int, int> place_in_comp;
        for (int i = 0; i < (int)component.size(); i++) {
            if (place_in_comp.find(component[i]) == place_in_comp.end()) {
                place_in_comp[component[i]] = i;
            }
        }

        while (!q.empty()) {
            int cur_bicomp = q.front();
            q.pop();

            for (int a : bicomp_to_art[cur_bicomp]) {
                for (int b : art_to_bicomp[a]) {
                    if (!merged[b]) {
                        q.push(b);
                        root_tree_with_root(trees[b], a);

                        merged[b] = true;
                        where_to_merge[b] =
                            trees[main_bicomp].merge(trees[b], place_in_comp, where_to_merge[cur_bicomp]);
                    }
                }
            }
        }

        for (int i = 0; i < trees[main_bicomp].size(); i++) {
            auto &t = trees[main_bicomp][i];

            if (t.children.empty()) continue;

            auto &face = t.face;

            std::vector<std::pair<int, int>> v_in_c;
            check_for_components(face, v_in_c);
            if (!v_in_c.empty()) {
                std::vector<std::vector<int>> components;
                std::map<int, int> v_to_c;
                get_component(components, v_to_c, v_in_c);

                if (components.size() > 1) {
                    make_connected(components, v_to_c, v_in_c);
                    components.clear();
                    v_to_c.clear();
                    get_component(components, v_to_c, v_in_c);
                }

                int face_v = v_in_c[0].second;
                for (auto e : v_in_c) {
                    if (e.second != face_v) {
                        face_v = -1;
                        break;
                    }
                }

                if (face_v > -1) {
                    int next_in_face = -1;
                    for (int v = 0; v < (int)face.size(); v++) {
                        if (face[v] == face_v) {
                            face_v = face[(v + 1) % face.size()];
                            next_in_face = face[(v + 2) % face.size()];
                            break;
                        }
                    }

                    int comp_v = v_in_c.back().first;
                    int pos_face = get_edge_it(embedding, face_v, next_in_face) + 1;
                    int pos_comp = get_edge_it(embedding, comp_v, face_v) + 1;
                    add_edge_emb(face_v, comp_v, pos_face, pos_comp, true);
                    int a = face_v, b = comp_v;
                    if (a > b) std::swap(a, b);
                    addedEdges.emplace(a, b);
                }

                triangulate(face, components[0], 1);

                std::rotate(face.begin(), std::find(face.begin(), face.end(), t.label.first), face.end());
                v_in_c.clear();
                check_for_components(face, v_in_c);
                components.clear();
                v_to_c.clear();
                components.emplace_back();

                int v = -1;
                if (t.label.first != t.label.second) {
                    v = find_third(t.label.first, t.label.second, components[0]);
                } else {
                    int w = -1;
                    for (int c = (int)t.children.size() - 1; c >= 0; c--) {
                        if (trees[main_bicomp][t.children[c]].label.first != t.label.first) {
                            w = trees[main_bicomp][t.children[c]].label.first;
                            break;
                        }
                    }
                    v = find_third(t.label.first, w, components[0]);
                }
                t.component_tree = build_tree_with_dividing_points(components[0], v);
                t.component_tree.enclosing_tree = &trees[main_bicomp];
                t.component_tree.enclosing_face = i;
            }
        }

        return trees[main_bicomp];
    }

    void create_boudaries_rec(Tree<IndependentSet> &t, int node) {
        if (t[node].children.empty()) return;
        for (int i : t[node].children) {
            create_boudaries_rec(t, i);
        }

        t[node].LB = t[t[node].children[0]].LB;
        t[node].RB = t[t[node].children.back()].RB;
    }

    void create_boudaries(Tree<IndependentSet> &t, Tree<IndependentSet> &t2, int root) {
        if (t.enclosing_tree != nullptr) {
            IndependentSet &f = t.get_enclosing_face();
            std::vector<int> y_table;
            y_table.push_back(t2[f.children[0]].label.first);

            for (int v : f.children) {
                y_table.push_back(t2[v].label.second);
            }

            std::vector<int> leaves;
            get_leaves(t, leaves, root);
            t[leaves[0]].LB = 0;
            t[leaves.back()].RB = (int)f.children.size();

            for (int j = 1; j < (int)leaves.size(); j++) {
                IndependentSet &v = t[leaves[j]];
                IndependentSet &w = t[leaves[j - 1]];
                HalfEdge one = {graph.getAnyEdgeId(w.label.first, w.label.second), w.label.first, w.label.second};
                HalfEdge two = {graph.getAnyEdgeId(v.label.first, v.label.second), v.label.first, v.label.second};

                std::set<int> dividing_points;
                int div = find_dividing_points(one, two, dividing_points);

                for (int i = w.LB; i < (int)y_table.size(); i++) {
                    if (y_table[i] == div) {
                        v.LB = w.RB = i;
                        break;
                    }
                }
            }

            create_boudaries_rec(t, root);
        } else {
            for (auto &node : t.t) {
                node.LB = node.label.first;
                node.RB = node.label.second;
            }
        }

        for (int i = 0; i < t.size(); i++) {
            IndependentSet &node = t[i];
            if (!node.component_tree.empty()) {
                create_boudaries(node.component_tree, t, node.component_tree.root);
            }
        }
    }

    void table(Tree<IndependentSet> &t, int v) {
        int level = t[v].level;

        if (!t[v].children.empty() && t[v].component_tree.empty()) {
            table(t, t[v].children[0]);
            t[v].val = t[t[v].children[0]].val;

            for (int i = 1; i < (int)t[v].children.size(); i++) {
                table(t, t[v].children[i]);
                t[v].merge(t[v].val, t[t[v].children[i]].val);
            }

            t[v].adjust(graph, addedEdges);
            return;
        } else if (!t[v].children.empty() && !t[v].component_tree.empty()) {
            auto &ct = t[v].component_tree;
            table(ct, ct.root);
            t[v].contract(ct[ct.root]);
            t[v].adjust(graph, addedEdges);
            return;
        } else if (level > 1) {
            std::vector<int> z_table;
            z_table.push_back(t.get_enclosing_face().get_child(0).label.first);
            for (int x : t.enclosing_tree->t[t.enclosing_face].children) {
                z_table.push_back(t.enclosing_tree->t[x].label.second);
            }

            if (z_table.front() == z_table.back()) {
                z_table.pop_back();
            }

            int edge_it = get_edge_it(embedding, t[v].label.first, t[v].label.second) - 1;
            if (edge_it < 0) edge_it = (int)embedding[t[v].label.first].size() - 1;
            HalfEdge &e = embedding[t[v].label.first][edge_it];
            int third = (e.u == t[v].label.first) ? e.v : e.u;
            int p = t[v].LB;
            for (int i = t[v].RB; i > t[v].LB; i--) {
                int idx = i;
                if (idx >= (int)z_table.size()) {
                    idx--;
                }
                if (z_table[idx] == third) {
                    p = idx;
                    break;
                }
            }

            t[v].create(p, graph, addedEdges);
            t[v].adjust(graph, addedEdges);

            int j = p - 1;
            while (j >= t[v].LB) {
                table(*t.enclosing_tree, t.enclosing_tree->t[t.enclosing_face].children[j]);
                IndependentSet second =
                    t.get_enclosing_face().get_child(j).extend(t[v].label.first, graph, addedEdges);
                t[v].merge(second.val, t[v].val);
                j--;
            }

            j = p;
            while (j < t[v].RB) {
                table(*t.enclosing_tree, t.enclosing_tree->t[t.enclosing_face].children[j]);
                IndependentSet second =
                    t.get_enclosing_face().get_child(j).extend(t[v].label.second, graph, addedEdges);
                t[v].merge(t[v].val, second.val);
                j++;
            }
        }
    }

    void reconstruct_node(Tree<IndependentSet> &t, int v, int leftMask, int rightMask,
                          std::vector<int> &out) {
        int level = t[v].level;
        if (level == 1 && t[v].children.empty() && t[v].component_tree.empty()) {
            if (leftMask & 1) out.push_back(t[v].label.first);
            if (rightMask & 1) out.push_back(t[v].label.second);
            return;
        }

        if (!t[v].children.empty() && t[v].component_tree.empty()) {
            int deg = (int)t[v].children.size();
            std::vector<std::vector<std::vector<int>>> prefixTables(deg);
            prefixTables[0] = t[t[v].children[0]].val;
            for (int i = 1; i < deg; i++) {
                prefixTables[i] = merge_tables(prefixTables[i - 1], t[t[v].children[i]].val, level);
            }

            int u = leftMask;
            int vmask = rightMask;
            for (int i = deg - 1; i >= 1; i--) {
                const auto &prev = prefixTables[i - 1];
                const auto &child = t[t[v].children[i]].val;
                int bestZ = -1;
                for (int z = 0; z < (1 << level); z++) {
                    int val = prev[u][z] + child[z][vmask] - popcount_mask(z, level);
                    if (val == prefixTables[i][u][vmask]) {
                        bestZ = z;
                        break;
                    }
                }
                if (bestZ < 0) break;
                reconstruct_node(t, t[v].children[i], bestZ, vmask, out);
                vmask = bestZ;
            }
            reconstruct_node(t, t[v].children[0], u, vmask, out);
            return;
        }

        if (!t[v].children.empty() && !t[v].component_tree.empty()) {
            auto &ct = t[v].component_tree;
            int u = leftMask;
            int r = rightMask;
            int val0 = ct[ct.root].val[u << 1][r << 1];
            int val1 = ct[ct.root].val[(u << 1) + 1][(r << 1) + 1];
            if (val1 >= val0 && val1 == t[v].val[u][r]) {
                reconstruct_node(ct, ct.root, (u << 1) + 1, (r << 1) + 1, out);
            } else {
                reconstruct_node(ct, ct.root, u << 1, r << 1, out);
            }
            return;
        }

        if (level > 1) {
            std::vector<int> z_table;
            z_table.push_back(t.get_enclosing_face().get_child(0).label.first);
            for (int x : t.enclosing_tree->t[t.enclosing_face].children) {
                z_table.push_back(t.enclosing_tree->t[x].label.second);
            }
            if (z_table.front() == z_table.back()) {
                z_table.pop_back();
            }

            int edge_it = get_edge_it(embedding, t[v].label.first, t[v].label.second) - 1;
            if (edge_it < 0) edge_it = (int)embedding[t[v].label.first].size() - 1;
            HalfEdge &e = embedding[t[v].label.first][edge_it];
            int third = (e.u == t[v].label.first) ? e.v : e.u;
            int p = t[v].LB;
            for (int i = t[v].RB; i > t[v].LB; i--) {
                int idx = i;
                if (idx >= (int)z_table.size()) idx--;
                if (z_table[idx] == third) {
                    p = idx;
                    break;
                }
            }

            IndependentSet base(level, &t);
            base.label = t[v].label;
            base.LB = t[v].LB;
            base.RB = t[v].RB;
            base.create(p, graph, addedEdges);
            base.adjust(graph, addedEdges);

            int leftCount = p - t[v].LB;
            int rightCount = t[v].RB - p;

            std::vector<std::vector<std::vector<int>>> leftTables(leftCount + 1);
            leftTables[0] = base.val;
            for (int idx = 0; idx < leftCount; idx++) {
                int childIdx = p - 1 - idx;
                IndependentSet ext =
                    t.get_enclosing_face().get_child(childIdx).extend(t[v].label.first, graph, addedEdges);
                leftTables[idx + 1] = merge_tables(ext.val, leftTables[idx], level);
            }

            std::vector<std::vector<std::vector<int>>> rightTables(rightCount + 1);
            rightTables[0] = leftTables[leftCount];
            for (int idx = 0; idx < rightCount; idx++) {
                int childIdx = p + idx;
                IndependentSet ext =
                    t.get_enclosing_face().get_child(childIdx).extend(t[v].label.second, graph, addedEdges);
                rightTables[idx + 1] = merge_tables(rightTables[idx], ext.val, level);
            }

            int u = leftMask;
            int r = rightMask;

            for (int idx = rightCount - 1; idx >= 0; idx--) {
                int childIdx = p + idx;
                IndependentSet ext =
                    t.get_enclosing_face().get_child(childIdx).extend(t[v].label.second, graph, addedEdges);
                const auto &prev = rightTables[idx];
                const auto &curr = rightTables[idx + 1];
                int bestZ = -1;
                for (int z = 0; z < (1 << level); z++) {
                    int val = prev[u][z] + ext.val[z][r] - popcount_mask(z, level);
                    if (val == curr[u][r]) {
                        bestZ = z;
                        break;
                    }
                }
                if (bestZ < 0) break;
                reconstruct_node(*t.enclosing_tree, t.enclosing_tree->t[t.enclosing_face].children[childIdx], bestZ, r,
                                 out);
                r = bestZ;
            }

            for (int idx = leftCount - 1; idx >= 0; idx--) {
                int childIdx = p - 1 - idx;
                IndependentSet ext =
                    t.get_enclosing_face().get_child(childIdx).extend(t[v].label.first, graph, addedEdges);
                const auto &prev = leftTables[idx];
                const auto &curr = leftTables[idx + 1];
                int bestZ = -1;
                for (int z = 0; z < (1 << level); z++) {
                    int val = ext.val[u][z] + prev[z][r] - popcount_mask(z, level);
                    if (val == curr[u][r]) {
                        bestZ = z;
                        break;
                    }
                }
                if (bestZ < 0) break;
                reconstruct_node(*t.enclosing_tree, t.enclosing_tree->t[t.enclosing_face].children[childIdx], u, bestZ,
                                 out);
                u = bestZ;
            }

            int baseMask = u;
            int baseMaskR = r;
            std::vector<int> vertices;
            if (p < (int)t.enclosing_tree->t[t.enclosing_face].children.size()) {
                IndependentSet &child = t.get_enclosing_face().get_child(p);
                child.get_left_boundary(vertices);
            } else {
                IndependentSet &child = t.get_enclosing_face().get_child(p - 1);
                child.get_right_boundary(vertices);
            }

            int subset = baseMask >> 1;
            for (int i = 0; i < (int)vertices.size(); i++) {
                if ((subset >> i) & 1) out.push_back(vertices[i]);
            }
            if (baseMask & 1) out.push_back(t[v].label.first);
            if (baseMaskR & 1) out.push_back(t[v].label.second);
        }
    }
};


} // namespace

std::vector<int> solveExactMIS(const std::vector<std::vector<int>> &adj,
                               const std::vector<int> &component,
                               const InducedEmbeddingData &embData) {
    if (component.empty()) return {};

    int n_local = (int)component.size();
    std::unordered_map<int, int> globalToLocal;
    globalToLocal.reserve(component.size() * 2);
    for (int i = 0; i < (int)component.size(); i++) {
        globalToLocal[component[i]] = i;
    }

    std::vector<std::vector<int>> ladj(n_local);
    for (int u_global : component) {
        int u = globalToLocal[u_global];
        for (int v_global : adj[u_global]) {
            auto it = globalToLocal.find(v_global);
            if (it == globalToLocal.end()) continue;
            int v = it->second;
            ladj[u].push_back(v);
        }
    }
    for (int u = 0; u < n_local; u++) {
        auto &vec = ladj[u];
        std::sort(vec.begin(), vec.end());
        vec.erase(std::unique(vec.begin(), vec.end()), vec.end());
    }

// === Constrói o BakerGraph e o embedding (rotação) SEM re-embedding ===
// Mapa (u,v) -> edgeId para localizar rapidamente o id da aresta
std::unordered_map<std::uint64_t, int> pairToEdge;
pairToEdge.reserve(n_local * 8);

BakerGraph g(n_local);
for (int u = 0; u < n_local; u++) {
    for (int v : ladj[u]) {
        if (u >= v) continue;
        int edgeId = g.addEdge(u, v, false);
        pairToEdge[edgeKey(u, v)] = edgeId;
    }
}

Embedding embedding(n_local);

// Monta rotação local: usa a rotação fornecida; se faltar algum vizinho,
// adiciona ao final (fallback defensivo).
for (int u = 0; u < n_local; u++) {
    std::vector<char> seen(n_local, 0);

    // Primeiro: ordem de rotação (preferida)
    if (u < (int)embData.rotation.size()) {
        for (int v : embData.rotation[u]) {
            if (v < 0 || v >= n_local) continue;
            // precisa ser vizinho real
            if (!std::binary_search(ladj[u].begin(), ladj[u].end(), v)) continue;

            auto it = pairToEdge.find(edgeKey(u, v));
            if (it == pairToEdge.end()) continue;
            int edgeId = it->second;

            embedding[u].push_back(HalfEdge{edgeId, u, v});
            seen[v] = 1;
        }
    }

    // Depois: completa com vizinhos que não apareceram na rotação
    for (int v : ladj[u]) {
        if (seen[v]) continue;
        auto it = pairToEdge.find(edgeKey(u, v));
        if (it == pairToEdge.end()) continue;
        int edgeId = it->second;
        embedding[u].push_back(HalfEdge{edgeId, u, v});
    }
}

// === Recupera o ciclo da face externa herdada ===
auto buildNextEdge = [&](const BakerGraph &gg, const Embedding &emb) {
    std::vector<std::array<int, 2>> nextEdge(gg.edges.size(), {{-1, -1}});
    for (int v = 0; v < (int)emb.size(); v++) {
        const auto &edges = emb[v];
        if (edges.empty()) continue;
        for (int i = 0; i < (int)edges.size(); i++) {
            int e = edges[i].edge;
            if (e < 0 || e >= (int)gg.edges.size()) continue;
            int idx = (gg.edges[e].u == v) ? 0 : 1;
            int nextId = edges[(i + 1) % edges.size()].edge;
            nextEdge[e][idx] = nextId;
        }
    }
    return nextEdge;
};

auto nextEdge = buildNextEdge(g, embedding);

auto traverseFaceFromDart = [&](int startEdge, int startV) -> std::vector<int> {
    std::vector<int> cyc;
    if (startEdge < 0 || startEdge >= (int)g.edges.size()) return cyc;
    if (startV < 0 || startV >= n_local) return cyc;

    int currEdge = startEdge;
    int currV = startV;
    int guard = 0;
    while (guard++ < (int)g.edges.size() * 4 + 10) {
        cyc.push_back(currV);

        int idx = (g.edges[currEdge].u == currV) ? 0 : 1;
        int nxtEdge = nextEdge[currEdge][idx];
        int nxtV = otherEndpoint(g.edges[currEdge], currV);

        currV = nxtV;
        currEdge = nxtEdge;

        if (currEdge == startEdge && currV == startV) break;
        if (currEdge < 0) break;
    }
    // remove duplicata final se existir (a travessia acima não adiciona o último startV,
    // mas mantemos defensivo)
    if (!cyc.empty() && cyc.front() == cyc.back()) cyc.pop_back();
    return cyc;
};

std::vector<int> outerFace;

// Tenta usar um dart marcado como externo no embedding global (mais fiel ao paper)
int startEdge = -1, startV = -1;
for (const auto &kv : embData.outerDarts) {
    int u = (int)(kv >> 32);
    int v = (int)(kv & 0xffffffffu);
    if (u < 0 || u >= n_local || v < 0 || v >= n_local) continue;
    auto it = pairToEdge.find(edgeKey(u, v));
    if (it == pairToEdge.end()) continue;
    startEdge = it->second;
    startV = u;
    break;
}
if (startEdge != -1) {
    outerFace = traverseFaceFromDart(startEdge, startV);
}

// Fallback: se não conseguimos identificar, escolhe a maior face (heurística)
if (outerFace.empty()) {
    std::vector<std::vector<int>> faces(g.edges.size());
    std::vector<std::vector<int>> vertices_in_face;
    FaceGetter vis(faces, vertices_in_face);
    level_face_traversal(g, embedding, vis);

    int best = -1, bestSz = -1;
    for (int f = 0; f < (int)vertices_in_face.size(); f++) {
        int sz = (int)vertices_in_face[f].size();
        if (sz > bestSz) { bestSz = sz; best = f; }
    }
    if (best >= 0) outerFace = vertices_in_face[best];
}

if (outerFace.empty()) return {};

BakerImpl impl(g, embedding, outerFace);
    std::vector<int> localSel = impl.solve();

    std::vector<int> result;
    result.reserve(localSel.size());
    for (int v_local : localSel) {
        if (v_local < 0 || v_local >= (int)component.size()) continue;
        result.push_back(component[v_local]);
    }
    return result;
}

} // namespace baker_exact