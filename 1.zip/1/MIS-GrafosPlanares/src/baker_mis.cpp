#include "baker_mis.hpp"
#include "baker_exact.hpp"

#include <ogdf/basic/basic.h>

// - Bibliotecas usadas para representação planar e face externa 
#include <ogdf/planarity/BoyerMyrvold.h> 
#include <ogdf/basic/CombinatorialEmbedding.h>

#include <algorithm>
#include <chrono>
#include <cstdint>
#include <deque>
#include <functional>
#include <iostream>
#include <limits>
#include <unordered_map>
#include <unordered_set>

// ============================
// Helpers gerais
// ============================

// - Função que conta bits de uma máscara (usado na programação dinâmica em bags)
static inline int popcount64(std::uint64_t x) {
#if defined(__GNUG__) || defined(__clang__)
    return __builtin_popcountll(x);
#else
    // fallback simples
    int c = 0;
    while (x) { x &= (x - 1); ++c; }
    return c;
#endif
}

// Cria um mapa id -> índice 0..(n-1) (assumimos idsOrig já é 0..n-1 como na sua main)
// - Função que recupera o valor de 'n'
static inline int inferNFromIds(const ogdf::Graph &G, const ogdf::NodeArray<int> &idsOrig) {
    int mx = -1;
    for (ogdf::node v : G.nodes) mx = std::max(mx, idsOrig[v]);
    return mx + 1;
}

// ============================
// BakerMIS::run
// ============================

// - Função que chama o algoritmo de Baker (versão atalho)
std::vector<int> BakerMIS::run(const ogdf::Graph &G,
                               const ogdf::NodeArray<int> &idsOrig) {
    return run(G, idsOrig, Params{}); // chama a versão com parâmetros
}

// - Função que chama o algoritmo de Baker (versão configurável)
//   --> Recebe como parâmetros: um grafo 'G', um conjunto de vértices 'idsOrig' e o conjunto de parâmetros 'p'
std::vector<int> BakerMIS::run(const ogdf::Graph &G,
                               const ogdf::NodeArray<int> &idsOrig,
                               const Params &p) {
    
    // - Determina o valor de 'n' do grafo 'G'
    const int n = inferNFromIds(G, idsOrig);
    

    // - Cria a lista de adjacência de 'G' por 'ID'
    std::vector<std::vector<int>> adj;
    buildAdjacencyById(G, idsOrig, adj);

    // - Declara o conjunto de níveis do grafo
    std::vector<int> levelById;
    std::vector<std::vector<int>> rotationById;
    std::unordered_set<size_t> outerDartsById;
    if (!computePlanarLevels(G, idsOrig, levelById, rotationById, outerDartsById)) {
        std::cerr << "[BakerMIS] ERRO: falha ao computar embedding/niveis.\n";
        return {};
    }

    // - Declara o conjunto solução 'bestI' 
    std::vector<int> bestI;
    bestI.reserve(n);

    // - Escopo do loop principal (Algoritmo 1: BAKER_MIS)
    for (int r = 0; r <= p.k; ++r) {
        // - Declara o conjunto 'active' usado para remover classe
        std::vector<char> active(n, 0);

        // - Loop para percorrer o conjunto de níveis
        for (int id = 0; id < n; ++id) {
            
            if (levelById[id] < 0) continue; // nó inexistente (não deve ocorrer se ids são 0..n-1)

            // - Calcula r (mod k+1)
            const int mod = levelById[id] % (p.k + 1);

            // - Marca nível como 'removido'
            if (mod != r) active[id] = 1;
        }

        // - Declara conjunto de componentes conexos
        std::vector<std::vector<int>> comps;

        // - Obtém componentes conexos do grafo
        connectedComponentsInduced(adj, active, comps);

        // - Declara conjunto solução da classe
        std::vector<int> Ir;

        // - Loop para percorrer o conjunto de componentes conexos
        for (const auto &C : comps) {
            if (C.empty()) continue;

            // - Declara o conjunto solução do componente e chama a função para resolver exatamente o MIS
            auto Ic = solveMIS_kOuterplanar_exact_TW(adj, C, rotationById, outerDartsById, p);


            // - Insere a solução do componente no conjunto de solução da classe
            Ir.insert(Ir.end(), Ic.begin(), Ic.end());
        }

        // - Escolhe o melhor conjunto entre as k+1 iterações
        if (Ir.size() > bestI.size()) bestI = std::move(Ir);
    }

    // - Remove duplicações e organiza os vértices do conjunto solução 
    std::sort(bestI.begin(), bestI.end());
    bestI.erase(std::unique(bestI.begin(), bestI.end()), bestI.end());
    return bestI;
}

// ============================
// Adjacência por ID
// ============================

// - Função que cria adjacência por IDs
//   --> Parâmetros: grafo 'G', lista de vértices 'idsOrig' e vetor 'adj' para armazenar a lista
void BakerMIS::buildAdjacencyById(const ogdf::Graph &G,
                                  const ogdf::NodeArray<int> &idsOrig,
                                  std::vector<std::vector<int>> &adj) {
    // - Obtém o 'n' do grafo
    const int n = inferNFromIds(G, idsOrig);
    adj.assign(n, {});

    // - Monta 'adj' a partir das arestas de um grafo 'OGDF'
    for (ogdf::edge e : G.edges) {
        int a = idsOrig[e->source()];
        int b = idsOrig[e->target()];
        if (a == b) continue;
        adj[a].push_back(b);
        adj[b].push_back(a);
    }

    // - Ordena lista
    for (int i = 0; i < n; ++i) {
        auto &v = adj[i];
        std::sort(v.begin(), v.end());
        v.erase(std::unique(v.begin(), v.end()), v.end());
    }
}

// ============================
// Componentes conexos no subgrafo induzido por active
// ============================

// -- Função que obtém os componentes conexos do grafo
//    --> Parâmetros: vetor 'adj' de adjacência, vetor 'active' para saber se uma classe foi removida do grafo, vetor 'comps' de componentes
void BakerMIS::connectedComponentsInduced(const std::vector<std::vector<int>> &adj,
                                          const std::vector<char> &active,
                                          std::vector<std::vector<int>> &comps) {
                                            
    // - Usa BFS e DFS no subgrafo induzido
    const int n = (int)adj.size();
    std::vector<char> vis(n, 0);

    for (int s = 0; s < n; ++s) {
        if (!active[s] || vis[s]) continue;
        std::vector<int> comp;
        std::deque<int> dq;
        dq.push_back(s);
        vis[s] = 1;

        while (!dq.empty()) {
            int u = dq.front();
            dq.pop_front();
            comp.push_back(u);

            for (int v : adj[u]) {
                if (!active[v] || vis[v]) continue;
                vis[v] = 1;
                dq.push_back(v);
            }
        }

        comps.push_back(std::move(comp));
    }
}

// ============================
// Níveis (Algoritmo 2 do seu PDF)
// Implementação prática:
// - Copiamos o grafo para H
// - Enquanto H não vazio: computa embedding planar, pega vértices da face externa,
//   marca nível e remove do H.
// Observação: isso pode ser mais caro que o "linear assumido" no artigo,
// mas mantém a definição de níveis do pseudocódigo.
// ============================

static void outerFaceVertices(ogdf::CombinatorialEmbedding &E,
                             std::vector<ogdf::node> &outNodes) {
    outNodes.clear();

    ogdf::face ext = E.externalFace();
    if (!ext) return;

    ogdf::adjEntry start = ext->firstAdj();
    ogdf::adjEntry a = start;

    // evita duplicados
    std::unordered_set<ogdf::node> seen;
    int guard = 0;
    const int guardMax = 1000000;

    do {
        ogdf::node v = a->theNode();
        if (seen.insert(v).second) outNodes.push_back(v);

        // caminha na borda da face (API típica OGDF)
        a = a->faceCycleSucc();

        if (++guard > guardMax) break;
    } while (a != start);
}


bool BakerMIS::computePlanarLevels(const ogdf::Graph &G,
                                  const ogdf::NodeArray<int> &idsOrig,
                                  std::vector<int> &levelById,
                                  std::vector<std::vector<int>> &rotationById,
                                  std::unordered_set<std::uint64_t> &outerDartsById) {
    // Estratégia "fiel ao espírito" da Baker / repo:
    // - Computa UM embedding planar do grafo.
    // - Calcula níveis via BFS no grafo radial (face <-> vértice), a partir da face externa.
    //
    // Robustez:
    // - Remove loops e ignora arestas paralelas ao copiar para H (evita falhas no embedding).
    // - Força o cálculo das faces (E.computeFaces()).
    // - Se ainda assim não conseguir determinar a face externa, faz fallback para o "peeling"
    //   (re-embedding por camada), que é mais caro mas bem robusto.

    // 1) Copia o grafo para H e mantém node(H) -> id original
    ogdf::Graph H;
    ogdf::NodeArray<int> idH(H, -1);

    std::unordered_map<int, ogdf::node> byId;
    byId.reserve(G.numberOfNodes() * 2);

    for (ogdf::node v : G.nodes) {
        ogdf::node u = H.newNode();
        int id = idsOrig[v];
        idH[u] = id;
        byId[id] = u;
    }

    // evita paralelas (baseado em idsOrig)
    std::unordered_set<unsigned long long> seenEdge;
    seenEdge.reserve(G.numberOfEdges() * 2);

    auto keyEdge = [](int a, int b) -> unsigned long long {
        if (a > b) std::swap(a, b);
        return ( (unsigned long long)(unsigned int)a << 32 ) | (unsigned int)b;
    };

    for (ogdf::edge e : G.edges) {
        int a = idsOrig[e->source()];
        int b = idsOrig[e->target()];
        if (a == b) continue; // loop

        auto ita = byId.find(a);
        auto itb = byId.find(b);
        if (ita == byId.end() || itb == byId.end()) continue;

        unsigned long long k = keyEdge(a, b);
        if (seenEdge.insert(k).second) {
            H.newEdge(ita->second, itb->second);
        }
    }

    // 2) Um único embedding planar
    ogdf::BoyerMyrvold bm;
    if (!bm.isPlanar(H)) return false;
    bm.planarEmbed(H);

    ogdf::CombinatorialEmbedding E(H);
    E.computeFaces(); // <<< importantíssimo para algumas builds/versões

    
    ogdf::face ext = E.externalFace();
    if (!ext) {
        // Escolhe uma face "externa" (heurística: maior comprimento de borda)
        auto faceSize = [&](ogdf::face f) -> int {
            if (!f) return 0;
            ogdf::adjEntry start = f->firstAdj();
            if (!start) return 0;
            int cnt = 0;
            ogdf::adjEntry a = start;
            do {
                ++cnt;
                a = a->faceCycleSucc();
            } while (a != start);
            return cnt;
        };

        ogdf::face best = nullptr;
        int bestSz = -1;

        for (ogdf::face f : E.faces) {              // <- na sua OGDF isso existe
            int sz = faceSize(f);
            if (sz > bestSz) { bestSz = sz; best = f; }
        }

        if (!best) {
            // Se não existe face nenhuma, algo está errado com o embedding
            return false;
        }

        E.setExternalFace(best);
        ext = best;
    }

    // daqui pra frente você usa "ext" normalmente


    // 3) BFS no grafo radial (face <-> vértice) para obter distâncias
    //    Distância 0: face externa
    //    Distância 1: vértices incidentes à face externa  -> nível 1
    //    Distância 3: nível 2, etc.
    //
    //    nível(v) = (distV(v)+1)/2, onde distV(v) é a menor distância (sempre ímpar)
    //    de ext até v alternando face-vértice-face-...

    ogdf::NodeArray<int> distV(H, -1);

    std::unordered_map<ogdf::face, int> distF;
    distF.reserve(2 * H.numberOfNodes() + 10);

    struct QItem {
        bool isFace;
        ogdf::face f;
        ogdf::node v;
    };

    std::deque<QItem> q;
    distF[ext] = 0;
    q.push_back(QItem{true, ext, nullptr});

    auto enqueueFaceIfNew = [&](ogdf::face f, int d) {
        if (!f) return;
        if (distF.find(f) != distF.end()) return;
        distF.emplace(f, d);
        q.push_back(QItem{true, f, nullptr});
    };

    auto enqueueVertexIfNew = [&](ogdf::node v, int d) {
        if (!v) return;
        if (distV[v] != -1) return;
        distV[v] = d;
        q.push_back(QItem{false, nullptr, v});
    };

    // Itera os vértices na borda de uma face (sem duplicar muito)
    auto boundaryVertices = [&](ogdf::face f, std::vector<ogdf::node> &out) {
        out.clear();
        ogdf::adjEntry start = f->firstAdj();
        if (!start) return;

        ogdf::adjEntry a = start;
        std::unordered_set<ogdf::node> seen;
        seen.reserve(16);

        int guard = 0;
        const int guardMax = 2000000;

        do {
            ogdf::node x = a->theNode();
            if (seen.insert(x).second) out.push_back(x);
            a = a->faceCycleSucc();
            if (++guard > guardMax) break;
        } while (a != start);
    };

    std::vector<ogdf::node> tmpBoundary;
    tmpBoundary.reserve(64);

    while (!q.empty()) {
        QItem it = q.front();
        q.pop_front();

        if (it.isFace) {
            ogdf::face f = it.f;
            int dF = distF[f];

            boundaryVertices(f, tmpBoundary);
            for (ogdf::node x : tmpBoundary) {
                enqueueVertexIfNew(x, dF + 1);
            }
        } else {
            ogdf::node v = it.v;
            int dV = distV[v];

            for (ogdf::adjEntry a : v->adjEntries) {
                ogdf::face fRight = E.rightFace(a);
                enqueueFaceIfNew(fRight, dV + 1);
            }
        }
    }

    // 4) Converte distâncias em níveis e grava em levelById
    for (ogdf::node v : H.nodes) {
        int id = idH[v];
        if (id < 0 || id >= (int)levelById.size()) continue;
        if (distV[v] < 0) {
            levelById[id] = 1;
        } else {
            levelById[id] = (distV[v] + 1) / 2;
        }
    }

    return true;
}

std::vector<int> BakerMIS::solveMIS_kOuterplanar_exact_TW(const std::vector<std::vector<int>> &adj,
                                                         const std::vector<int> &component,
                                                         const std::vector<std::vector<int>> &rotationById,
                                                         const std::unordered_set<std::uint64_t> &outerDartsById,
                                                         const Params &p) {
(void)p;

// Constrói dados de embedding induzidos para ESTE componente (em índices locais)
baker_exact::InducedEmbeddingData embData;

const int n_local = (int)component.size();
embData.rotation.assign(n_local, {});

std::unordered_map<int, int> globalToLocal;
globalToLocal.reserve(component.size() * 2);
for (int i = 0; i < (int)component.size(); i++) {
    globalToLocal[component[i]] = i;
}

// rotação local: filtra a rotação global para apenas vizinhos no componente
for (int u_global : component) {
    int u = globalToLocal[u_global];
    if (u_global < 0 || u_global >= (int)rotationById.size()) continue;
    for (int v_global : rotationById[u_global]) {
        auto it = globalToLocal.find(v_global);
        if (it == globalToLocal.end()) continue;
        embData.rotation[u].push_back(it->second);
    }
}

// darts externos locais: filtra outerDartsById para apenas pares dentro do componente
auto dirKey = [](int u, int v) -> std::uint64_t {
    return (static_cast<std::uint64_t>(static_cast<unsigned int>(u)) << 32) |
           static_cast<unsigned int>(v);
};
embData.outerDarts.clear();
for (const auto &kv : outerDartsById) {
    int ug = (int)(kv >> 32);
    int vg = (int)(kv & 0xffffffffu);
    auto itU = globalToLocal.find(ug);
    auto itV = globalToLocal.find(vg);
    if (itU == globalToLocal.end() || itV == globalToLocal.end()) continue;
    embData.outerDarts.insert(dirKey(itU->second, itV->second));
}

return baker_exact::solveExactMIS(adj, component, embData);
}