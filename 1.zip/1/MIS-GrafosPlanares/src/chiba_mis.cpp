#include "chiba_mis.hpp"

#include <ogdf/basic/simple_graph_alg.h>
#include <ogdf/basic/extended_graph_alg.h>
#include <ogdf/planarity/PlanarizationLayout.h>
#include <algorithm>
#include <unordered_map>
#include <stdexcept>

using namespace ogdf;

static std::unordered_set<int> toSet(const std::vector<int> &v) {
    return std::unordered_set<int>(v.begin(), v.end());
}

static bool edgeExistsUndir(const ogdf::Graph &g, ogdf::node a, ogdf::node b) {
    return g.searchEdge(a, b) != nullptr || g.searchEdge(b, a) != nullptr;
}

std::vector<int> ChibaMIS::run(const Graph &G, const NodeArray<int> &idsOrig) {
    Instance I;
    // copia nós preservando IDs
    std::unordered_map<int, node> id2n;
    for (node v : G.nodes) {
        node nv = I.g.newNode();
        I.origId[nv] = idsOrig[v];
        id2n[I.origId[nv]] = nv;
    }
    // copia arestas (por IDs)
    for (edge e : G.edges) {
        int a = idsOrig[e->source()];
        int b = idsOrig[e->target()];
        node na = id2n.at(a);
        node nb = id2n.at(b);
        if (na != nb && !edgeExistsUndir(I.g, na, nb)) I.g.newEdge(na, nb);
    }
    makeSimpleUndirected(I.g);

    auto sol = indpt(I);
    std::sort(sol.begin(), sol.end());
    sol.erase(std::unique(sol.begin(), sol.end()), sol.end());
    return sol;
}

std::vector<int> ChibaMIS::indpt(const Instance &I) {
    if (I.g.numberOfNodes() == 0) return {};

    node v = pickMinDegreeVertex(I.g);
    int dv = v->degree();

    // grau <= 2: remove v e N(v), recursa, adiciona v
    if (dv <= 2) {
        std::unordered_set<int> removed;
        removed.insert(I.origId[v]);
        for (node u : neighbors(I.g, v)) removed.insert(I.origId[u]);

        Instance Ip = buildReduced(I, removed, {});
        auto S = indpt(Ip);
        S.push_back(I.origId[v]);
        return S;
    }

    // grau 3: DEGREE3
    if (dv == 3) {
        auto N = neighbors(I.g, v);
        node v1 = N[0], v2 = N[1], v3 = N[2];

    // No artigo: entra no caso "join" quando NÃO há arestas entre os vizinhos
    bool noEdgesAmongNeighbors =
        !hasEdge(I.g, v1, v2) &&
        !hasEdge(I.g, v2, v3) &&
        !hasEdge(I.g, v3, v1);

    if (noEdgesAmongNeighbors) {
        // G' = G - {v, v2, v3}; join v1 to neighbors of v2 or v3
        std::unordered_set<int> removed = { I.origId[v], I.origId[v2], I.origId[v3] };
        std::vector<std::pair<int,int>> joins = {
            { I.origId[v1], I.origId[v2] },
            { I.origId[v1], I.origId[v3] }
        };
        Instance Ip = buildReduced(I, removed, joins);
        auto S = indpt(Ip);
        auto SS = toSet(S);

        if (SS.count(I.origId[v1])) {
            // Artigo: se v1 ∈ I(G') então adiciona {v2, v3}
            S.push_back(I.origId[v2]);
            S.push_back(I.origId[v3]);
        } else {
            S.push_back(I.origId[v]);
        }
        return S;
    } else {
        // Senão: G' = G - ({v} ∪ N(v)); I(G) = I(G') ∪ {v}
        std::unordered_set<int> removed = { I.origId[v], I.origId[v1], I.origId[v2], I.origId[v3] };
        Instance Ip = buildReduced(I, removed, {});
        auto S = indpt(Ip);
        S.push_back(I.origId[v]);
        return S;
    }

    }

    // grau 4: DEGREE4
    if (dv == 4) {
        auto cyc = cyclicNeighborsPlanar(I, v);
        if (cyc.size() != 4) {
            // fallback seguro: qualquer ordem
            cyc = neighbors(I.g, v);
        }
        node v1 = cyc[0], v2 = cyc[1], v3 = cyc[2], v4 = cyc[3];

        // H4 case (interpretação padrão da Fig.1 do artigo)
        if (isH4Case(I, v, cyc)) {
            // G' = G - {v, v2, v4}; join v1 to neighbors of v2; join v3 to neighbors of v4
            std::unordered_set<int> removed = { I.origId[v], I.origId[v2], I.origId[v4] };
            std::vector<std::pair<int,int>> joins = {
                { I.origId[v1], I.origId[v2] },
                { I.origId[v3], I.origId[v4] }
            };
            Instance Ip = buildReduced(I, removed, joins);
            auto S = indpt(Ip);
            auto SS = toSet(S);

            // encadeamento do pseudocódigo (equivalente a if/else-if/else):
            // Fiel ao pseudocódigo do artigo (3 ifs separados)
            if (!SS.count(I.origId[v1]) && !SS.count(I.origId[v3])) {
                S.push_back(I.origId[v]);
            }
            if (SS.count(I.origId[v1])) {
                S.push_back(I.origId[v2]);
            }
            if (!SS.count(I.origId[v1]) && SS.count(I.origId[v3])) {
                S.push_back(I.origId[v4]);
            }
            return S;

        } else {
            // caso "H contém H'4 ou H''4 e (v1,v3) é aresta" (Lemma 1 do artigo)
            // garantimos que (v1,v3) seja aresta ajustando rotação se possível
            auto best = cyc;
            bool ok = hasEdge(I.g, best[0], best[2]);
            if (!ok) {
                // tenta rotações para obter aresta (vi, v_{i+2})
                for (int shift = 0; shift < 4 && !ok; ++shift) {
                    std::rotate(best.begin(), best.begin()+1, best.end());
                    ok = hasEdge(I.g, best[0], best[2]);
                }
            }
            // se mesmo assim não achar, segue com a melhor tentativa (robustez)
            v1 = best[0]; v2 = best[1]; v3 = best[2]; v4 = best[3];

            // G' = G - {v, v2, v3, v4}; join v1 to neighbors of v3
            std::unordered_set<int> removed = { I.origId[v], I.origId[v2], I.origId[v3], I.origId[v4] };
            std::vector<std::pair<int,int>> joins = { { I.origId[v1], I.origId[v3] } };
            Instance Ip = buildReduced(I, removed, joins);
            auto S = indpt(Ip);
            auto SS = toSet(S);
            if (SS.count(I.origId[v1])) S.push_back(I.origId[v3]);
            else S.push_back(I.origId[v]);
            return S;
        }
    }

    // grau 5: DEGREE5
    if (dv == 5) {
        auto cyc = cyclicNeighborsPlanar(I, v);
        if (cyc.size() != 5) cyc = neighbors(I.g, v);

        // tenta garantir (v1,v3) aresta via rotação
        bool ok = hasEdge(I.g, cyc[0], cyc[2]);
        for (int shift = 0; shift < 5 && !ok; ++shift) {
            std::rotate(cyc.begin(), cyc.begin()+1, cyc.end());
            ok = hasEdge(I.g, cyc[0], cyc[2]);
        }
        node v1 = cyc[0], v2 = cyc[1], v3 = cyc[2], v4 = cyc[3], v5 = cyc[4];

        // G' = G - {v, v2, v3, v4, v5}; join v1 to neighbors of v3
        std::unordered_set<int> removed = {
            I.origId[v], I.origId[v2], I.origId[v3], I.origId[v4], I.origId[v5]
        };
        std::vector<std::pair<int,int>> joins = { { I.origId[v1], I.origId[v3] } };
        Instance Ip = buildReduced(I, removed, joins);
        auto S = indpt(Ip);
        auto SS = toSet(S);
        if (SS.count(I.origId[v1])) S.push_back(I.origId[v3]);
        else S.push_back(I.origId[v]);
        return S;
    }

    // Em planar, min degree <= 5; mas por segurança:
    throw std::runtime_error("ChibaMIS: grau mínimo > 5 (algo errado com o grafo/implementação).");
}

node ChibaMIS::pickMinDegreeVertex(const Graph &g) {
    node best = nullptr;
    int bestDeg = 1e9;
    for (node v : g.nodes) {
        int d = v->degree();
        if (d < bestDeg) { bestDeg = d; best = v; }
    }
    return best;
}

std::vector<node> ChibaMIS::neighbors(const Graph &g, node v) {
    std::vector<node> N;
    N.reserve(v->degree());
    for (adjEntry adj : v->adjEntries) {
        N.push_back(adj->twinNode());
    }
    // remove duplicatas, por segurança (multi-arestas)
    std::sort(N.begin(), N.end());
    N.erase(std::unique(N.begin(), N.end()), N.end());
    return N;
}

bool ChibaMIS::hasEdge(const Graph &g, node a, node b) {
    if (!a || !b) return false;
    return g.searchEdge(a, b) != nullptr || g.searchEdge(b, a) != nullptr;
}

ChibaMIS::Instance ChibaMIS::buildReduced(
    const Instance &I,
    const std::unordered_set<int> &removedOrigIds,
    const std::vector<std::pair<int,int>> &joins
) {
    Instance R;

    // cria nós remanescentes
    std::unordered_map<int, node> id2n;
    for (node v : I.g.nodes) {
        int id = I.origId[v];
        if (removedOrigIds.count(id)) continue;
        node nv = R.g.newNode();
        R.origId[nv] = id;
        id2n[id] = nv;
    }

    // copia arestas entre remanescentes
    for (edge e : I.g.edges) {
        int a = I.origId[e->source()];
        int b = I.origId[e->target()];
        if (removedOrigIds.count(a) || removedOrigIds.count(b)) continue;
        node na = id2n.at(a);
        node nb = id2n.at(b);
        if (na != nb && !edgeExistsUndir(R.g, na, nb)) R.g.newEdge(na, nb);
    }

    // aplica "joining": center -> todos vizinhos de deleted (no grafo original), exceto removidos/center
    // Para isso precisamos conhecer adjacências no grafo I.g.
    // Monta map id -> node original
    std::unordered_map<int, node> origId2node;
    origId2node.reserve(I.g.numberOfNodes()*2);
    for (node v : I.g.nodes) origId2node[I.origId[v]] = v;

    for (auto [centerId, deletedId] : joins) {
        if (removedOrigIds.count(centerId)) continue;
        if (!id2n.count(centerId)) continue; // center pode ter sido removido
        if (!origId2node.count(deletedId)) continue;

        node centerNew = id2n.at(centerId);
        node deletedOld = origId2node.at(deletedId);

        for (adjEntry adj : deletedOld->adjEntries) {
            node xOld = adj->twinNode();
            int xId = I.origId[xOld];
            if (removedOrigIds.count(xId)) continue;
            if (xId == centerId) continue;
            if (!id2n.count(xId)) continue; // pode não existir no reduzido
            node xNew = id2n.at(xId);
            if (centerNew != xNew && !edgeExistsUndir(R.g, centerNew, xNew)) {
                R.g.newEdge(centerNew, xNew);
            }
        }
    }

    makeSimpleUndirected(R.g);
    return R;
}

std::vector<node> ChibaMIS::cyclicNeighborsPlanar(const Instance &I, node v) {
    // tenta obter embedding planar e usar ordem das adjacências em adjEntries
    // OBS: OGDF mantém ordem circular em adjEntries quando há embedding.
    // Se não houver, tentamos planarizar.
    Graph gCopy;
    NodeArray<node> mapOldToNew(I.g, nullptr);
    for (node u : I.g.nodes) mapOldToNew[u] = gCopy.newNode();
    for (edge e : I.g.edges) gCopy.newEdge(mapOldToNew[e->source()], mapOldToNew[e->target()]);
    makeSimpleUndirected(gCopy);

    if (!isPlanar(gCopy)) {
        return neighbors(I.g, v);
    }

    // constrói embedding

    planarEmbed(gCopy);

    // como estamos num grafo copiado, pegamos o correspondente de v:
    node v2 = mapOldToNew[v];

    std::vector<node> cycNew;
    for (adjEntry adj : v2->adjEntries) cycNew.push_back(adj->twinNode());

    // mapeia de volta para nós originais usando origId (via grau e IDs)
    // estratégia: pegar IDs dos vizinhos em gCopy e casar por ID original do grafo I.g
    // como gCopy não tem origId, usamos uma correspondência por posição: construímos map new->old
    std::unordered_map<node, node> newToOld;
    for (node oldN : I.g.nodes) {
        newToOld[mapOldToNew[oldN]] = oldN;
    }

    // remove duplicatas
    // dedup preservando a ordem cíclica (não pode ordenar!)
    std::vector<node> cycOld;
    cycOld.reserve(cycNew.size());

    std::unordered_set<int> seen;
    seen.reserve(cycNew.size() * 2);

    for (node nn : cycNew) {
        node old = newToOld.at(nn);
        int id = I.origId[old];
        if (!seen.count(id)) {
            seen.insert(id);
            cycOld.push_back(old);
        }
    }
    return cycOld;

}

bool ChibaMIS::isH4Case(const Instance &I, node v, const std::vector<node> &cyc4) {
    if (cyc4.size() != 4) return false;
    node v1 = cyc4[0], v2 = cyc4[1], v3 = cyc4[2], v4 = cyc4[3];

    // v adjacente a todos (por definição de N(v) no caso grau 4)
    // H4: vizinhos formam ciclo v1-v2-v3-v4-v1 e NÃO têm diagonais v1-v3 e v2-v4
    bool cycle =
        hasEdge(I.g, v1, v2) &&
        hasEdge(I.g, v2, v3) &&
        hasEdge(I.g, v3, v4) &&
        hasEdge(I.g, v4, v1);

    bool diagonals = hasEdge(I.g, v1, v3) || hasEdge(I.g, v2, v4);

    return cycle && !diagonals;
}
