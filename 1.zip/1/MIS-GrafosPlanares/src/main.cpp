#include "baker_mis.hpp"
#include "PlanarRandomDataset.hpp"

#include <ogdf/basic/Graph.h>
#include <ogdf/basic/basic.h>

#include <chrono>
#include <fstream>
#include <iostream>
#include <string>
#include <unordered_set>
#include <vector>

using namespace ogdf;

// Verifica se S (por IDs) é independente no grafo G, dado idsOrig (node -> id)
static bool isIndependentSet(const Graph &G, const NodeArray<int> &idsOrig, const std::vector<int> &S) {
    std::unordered_set<int> sel;
    sel.reserve(S.size() * 2);
    for (int id : S) sel.insert(id);

    for (edge e : G.edges) {
        int a = idsOrig[e->source()];
        int b = idsOrig[e->target()];
        if (sel.count(a) && sel.count(b)) return false;
    }
    return true;
}

static bool hasNoDuplicateIds(const std::vector<int> &S) {
    std::unordered_set<int> seen;
    seen.reserve(S.size() * 2);
    for (int id : S) {
        if (seen.count(id)) return false;
        seen.insert(id);
    }
    return true;
}

static bool hasOnlyValidIds(const Graph &G, const NodeArray<int> &idsOrig, const std::vector<int> &S) {
    std::unordered_set<int> idsInGraph;
    idsInGraph.reserve(G.numberOfNodes() * 2);

    for (node v : G.nodes) idsInGraph.insert(idsOrig[v]);

    for (int id : S) {
        if (!idsInGraph.count(id)) return false;
    }
    return true;
}

static void assignSequentialIds(const Graph &G, NodeArray<int> &idsOrig) {
    int id = 0;
    for (node v : G.nodes) idsOrig[v] = id++;
}

int main(int argc, char **argv) {
    std::string outCsv = "baker_random_results.csv";
    if (argc >= 2) outCsv = argv[1];

    // ======= CONFIG (ajuste aqui) =======
    //int reps = 5;
    int reps = 1;
    //std::vector<int> sizes = {200, 500, 1000};
    std::vector<int> sizes = {50, 100, 200};
    std::vector<double> cs = {1.2, 1.8, 2.4};

    std::vector<mis::gen::PlanarGenType> types = {
        //mis::gen::PlanarGenType::Connected,
        mis::gen::PlanarGenType::Biconnected,
        mis::gen::PlanarGenType::Triconnected
    };

    std::uint32_t baseSeed = 12345;
    mis::gen::SeedMode seedMode = mis::gen::SeedMode::ParamHash;

    // parâmetro k da Baker (k>=1)
    int k = 8;

    // (segurança) limite de bag na DP
    int maxBagAllowed = 28;
    // ===================================

    std::ofstream out(outCsv);
    if (!out) {
        std::cerr << "Erro: nao consegui abrir CSV para escrita: " << outCsv << "\n";
        return 1;
    }

    out << "type,n,m_target,m_used,rep,seed,n_actual,m_actual,k,mis_size,"
           "is_independent,unique_ids,valid_ids,time_ms\n";

    long long total = 0;
    long long skipped = 0;

    for (auto t : types) {
        for (int n : sizes) {
            int mMax = mis::gen::maxPlanarEdges(n);
            int mMin = mis::gen::minEdges(t, n);

            for (double c : cs) {
                int mTarget = (int) llround(c * (double)n);

                if (mTarget < mMin || mTarget > mMax) {
                    skipped += reps;
                    continue;
                }

                int mUsed = std::max(mMin, std::min(mTarget, mMax));

                for (int rep = 0; rep < reps; rep++) {
                    total++;

                    std::uint32_t seed = baseSeed;
                    if (seedMode == mis::gen::SeedMode::ParamHash) {
                        std::uint32_t x = baseSeed;
                        x ^= (std::uint32_t)n * 0x9E3779B1u;
                        x ^= (std::uint32_t)mUsed * 0x85EBCA6Bu;
                        x ^= (std::uint32_t)rep * 0xC2B2AE35u;
                        x ^= (std::uint32_t)((int)(c * 1000)) * 0x27D4EB2Fu;
                        x ^= (std::uint32_t)((int)t + 1) * 0x165667B1u;
                        x ^= x << 13; x ^= x >> 17; x ^= x << 5;
                        seed = x;
                    } else {
                        seed = baseSeed + (std::uint32_t)(total & 0xffffffffu);
                    }

                    Graph G;
                    mis::gen::generateSingle(t, G, n, mUsed, seed);

                    int nA = G.numberOfNodes();
                    int mA = G.numberOfEdges();

                    NodeArray<int> idsOrig(G, -1);
                    assignSequentialIds(G, idsOrig);

                    BakerMIS::Params bp;
                    bp.k = k;
                    bp.maxFrontierSizeAllowed = maxBagAllowed;

                    auto t0 = std::chrono::steady_clock::now();
                    auto S = BakerMIS::run(G, idsOrig, bp);
                    auto t1 = std::chrono::steady_clock::now();

                    double ms = std::chrono::duration<double, std::milli>(t1 - t0).count();

                    bool indep = isIndependentSet(G, idsOrig, S);
                    bool uniqueIds = hasNoDuplicateIds(S);
                    bool validIds  = hasOnlyValidIds(G, idsOrig, S);

                    out << mis::gen::toString(t) << ","
                        << n << ","
                        << mTarget << ","
                        << mUsed << ","
                        << rep << ","
                        << seed << ","
                        << nA << ","
                        << mA << ","
                        << k << ","
                        << (int)S.size() << ","
                        << (indep ? 1 : 0) << ","
                        << (uniqueIds ? 1 : 0) << ","
                        << (validIds ? 1 : 0) << ","
                        << ms
                        << "\n";

                    std::cout << "[" << total << "] "
                              << mis::gen::toString(t)
                              << " n=" << nA << " m=" << mA
                              << " k=" << k
                              << " |S|=" << S.size()
                              << " indep=" << (indep ? "ok" : "FAIL")
                              << " unique=" << (uniqueIds ? "ok" : "FAIL")
                              << " valid=" << (validIds ? "ok" : "FAIL")
                              << " time=" << ms << "ms\n";
                }
            }
        }
    }

    std::cout << "\nGerados/testados: " << total << " (skipped aprox: " << skipped << ")\n";
    std::cout << "CSV: " << outCsv << "\n";
    return 0;
}
