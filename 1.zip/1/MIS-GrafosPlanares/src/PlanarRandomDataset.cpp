/*
    - Implementação das funções de geração dos grafos planares aleatórios
*/

#include "PlanarRandomDataset.hpp"

#include <ogdf/basic/basic.h> // ogdf::setSeed
#include <ogdf/basic/graph_generators/randomized.h>
#include <ogdf/fileformats/GraphIO.h>

#include <algorithm>
#include <cmath>
#include <fstream>
#include <sstream>

namespace fs = std::filesystem;

namespace mis::gen {

// - Definição dos tipos de grafos planares gerados
std::string toString(PlanarGenType t) {
    switch (t) {
        case PlanarGenType::Connected: return "connected";
        case PlanarGenType::Biconnected: return "biconnected";
        case PlanarGenType::Triconnected: return "triconnected";
    }
    return "unknown";
} 

// - Definição dos valores máximos para |E| 
int maxPlanarEdges(int n) {
    if (n <= 1) return 0; 
    if (n == 2) return 1;
    return 3 * n - 6; //
}

// - Definição dos valores mínimos para |E|
int minEdges(PlanarGenType t, int n) {
    if (n <= 1) return 0;
    switch (t) {
        case PlanarGenType::Connected:    return n - 1;
        case PlanarGenType::Biconnected:  return n;                 // ciclo
        case PlanarGenType::Triconnected: return (3 * n + 1) / 2;   // ceil(3n/2)
    }
    return 0;
}

// - Limita um valor inteiro para um dado intervalo
static int clampInt(int x, int lo, int hi) {
    return std::max(lo, std::min(x, hi));
}

// - Transformar o ponto para "p" no arquivo final
static std::string cToToken(double c) {
    std::ostringstream oss;
    oss << c;
    std::string s = oss.str();
    std::replace(s.begin(), s.end(), '.', 'p'); // 1.5 -> 1p5
    return s;
}

// Seed por parâmetros (independente da ordem dos loops)
static std::uint32_t seedFromParams(std::uint32_t base, int n, int m, double c, int rep, PlanarGenType t) {
    std::uint32_t x = base;
    x ^= (std::uint32_t)n * 0x9E3779B1u;
    x ^= (std::uint32_t)m * 0x85EBCA6Bu;
    x ^= (std::uint32_t)rep * 0xC2B2AE35u;
    x ^= (std::uint32_t)((int)(c * 1000)) * 0x27D4EB2Fu;
    x ^= (std::uint32_t)((int)t + 1) * 0x165667B1u;

    // xorshift (mistura barata)
    x ^= x << 13; x ^= x >> 17; x ^= x << 5;
    return x;
}

// Seed sequencial (simples, mas muda se mudar a ordem/quantidade de combinações)
static std::uint32_t seedSequential(std::uint32_t base, std::uint64_t runId) {
    return base + (std::uint32_t)(runId & 0xffffffffu);
}

// - Define qual seed usar 
static std::uint32_t computeSeed(const GenerationConfig &cfg,
                                 int n, int m, double c, int rep, PlanarGenType t,
                                 std::uint64_t runId) {
    if (cfg.seedMode == SeedMode::ParamHash) {
        return seedFromParams(cfg.baseSeed, n, m, c, rep, t);
    }
    return seedSequential(cfg.baseSeed, runId);
}

// - Gera um único grafo planar conforme o tipo "t", com "n" vértices + "m" arestas e semente "seed"
void generateSingle(PlanarGenType t, ogdf::Graph &G, int n, int m, std::uint32_t seed) {
    ogdf::setSeed((int)(seed & 0x7fffffff));
    G.clear();

    switch (t) {
        case PlanarGenType::Connected:
            ogdf::randomPlanarConnectedGraph(G, n, m);
            break;
        case PlanarGenType::Biconnected:
            ogdf::randomPlanarBiconnectedGraph(G, n, m, /*multiEdges=*/false);
            break;
        case PlanarGenType::Triconnected:
            ogdf::randomPlanarTriconnectedGraph(G, n, m);
            break;
    }
}

// - Gera todo o dataset randômico de grafos planares para testes
GenerationStats generateDataset(const GenerationConfig &cfg) {
    GenerationStats stats{};
    fs::create_directories(cfg.outDir);

    std::ofstream manifest(cfg.outDir / "manifest.csv");
    manifest << "status,type,n,c,m_target,m_used,n_actual,m_actual,rep,seed,file\n";

    std::uint64_t runId = 0;

    for (PlanarGenType t : cfg.types) {
        for (int n : cfg.sizes) {
            const int mMax = maxPlanarEdges(n);
            const int mMin = minEdges(t, n);

            for (double c : cfg.cs) {
                const int mTarget = (int)std::llround(c * (double)n);

                // invalidez por faixa
                if (mTarget < mMin || mTarget > mMax) {
                    stats.skipped++;
                    manifest << "skipped," << toString(t) << "," << n << "," << c
                             << "," << mTarget << ","
                             << "" << "," << "" << "," << ""
                             << "," << "" << "," << "" << "," << "" << "\n";
                    continue;
                }

                for (int rep = 0; rep < cfg.reps; rep++) {
                    runId++;

                    const int mUsed = clampInt(mTarget, mMin, mMax);
                    const std::uint32_t seed = computeSeed(cfg, n, mUsed, c, rep, t, runId);

                    ogdf::Graph G;
                    generateSingle(t, G, n, mUsed, seed);

                    const int nA = G.numberOfNodes();
                    const int mA = G.numberOfEdges();

                    const std::string fname =
                        toString(t) + "_n" + std::to_string(n) +
                        "_c" + cToToken(c) +
                        "_m" + std::to_string(mUsed) +
                        "_rep" + std::to_string(rep) +
                        "_seed" + std::to_string(seed) + cfg.extension;

                    const fs::path outFile = cfg.outDir / fname;

                    if (!ogdf::GraphIO::write(G, outFile.string())) {
                        stats.writeFail++;
                        manifest << "write_fail," << toString(t) << "," << n << "," << c
                                 << "," << mTarget << "," << mUsed
                                 << "," << nA << "," << mA
                                 << "," << rep << "," << seed << "," << outFile.string() << "\n";
                        continue;
                    }

                    stats.generated++;
                    manifest << "ok," << toString(t) << "," << n << "," << c
                             << "," << mTarget << "," << mUsed
                             << "," << nA << "," << mA
                             << "," << rep << "," << seed << "," << outFile.string() << "\n";
                }
            }
        }
    }

    return stats;
}

} // namespace mis::gen
